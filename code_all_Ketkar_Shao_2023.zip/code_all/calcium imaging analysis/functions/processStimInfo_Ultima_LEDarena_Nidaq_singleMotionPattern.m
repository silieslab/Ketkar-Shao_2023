function stimulusTrace = processStimInfo_Ultima_LEDarena_Nidaq_singleMotionPair(stimFile,nFrames,impVs,impStimVals)
% only for one mirror-symmetric pair of moving patterns. Needs improvements
% in order to suit every speed, wavelength etc.
load(stimFile.name,'data','stimSeq','pat_id','patNames');
smoothStimVoltage=round(data(:,2));
stimulusTrace = zeros(nFrames,1);
frameChangeInds=find(diff(data(:,1)))+1; %Where microscope frames change
% first assign impStimVals that pairs with current voltage.
% e.g. 1 to adapting luminance and 0 to OFF step
for iFrame=1:nFrames
    stimVoltage=smoothStimVoltage(frameChangeInds(iFrame));
    stimulusTrace(iFrame)=impStimVals(impVs==stimVoltage);
    %hardcoding to be removed
% %     intervalCheck1=0; intervalCheck2=0;
% %     %when pattern repeats within an epoch, the impVs also occurs in the middle of epoch
% %     if frameChangeInds(iFrame)-125>0
% %         intervalCheck1=smoothStimVoltage(frameChangeInds(iFrame)-125);
% %     end
% %     if frameChangeInds(iFrame)+125<size(data,1)
% %         intervalCheck2=smoothStimVoltage(frameChangeInds(iFrame)+125);
% %     end
% %     %now check for interval by all conditions
% %     if stimVoltage==impVs && (intervalCheck1==impVs || intervalCheck2==impVs)
% %         stimulusTrace(iFrame)=impStimVals(impVs==stimVoltage);
% %     else
% %         stimulusTrace(iFrame)=1;
% %     end
end

% %find if a pattern moves left or right, assign 1 for right, -1 for left
% leftOrRight=zeros(length(patNames),1);
% for iPat=1:length(patNames)
%     if strfind(patNames{iPat},'_r_')
%        leftOrRight(iPat)=1;
%     elseif strfind(patNames{iPat},'_l_')
%         leftOrRight(iPat)=-1;
%     end
% end

% %now incorporate the motion direction
% stimIds=reshape(stimSeq,[numel(stimSeq),1]); %straightening the matrix
% stimChangeInds=find(diff(stimulusTrace)<0)+1;
% stimChangeInds(end)=[];
% for iEpoch=1:numel(stimIds)
%     currentDirection=leftOrRight(pat_id==stimIds(iEpoch));
%     if iEpoch==numel(stimChangeInds)
%         stimulusTrace(stimChangeInds(iEpoch):end)=...
%         stimulusTrace(stimChangeInds(iEpoch):end) *currentDirection;
%     else
%         stimulusTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1)=...
%         stimulusTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1) *currentDirection;
%     end
% end
end