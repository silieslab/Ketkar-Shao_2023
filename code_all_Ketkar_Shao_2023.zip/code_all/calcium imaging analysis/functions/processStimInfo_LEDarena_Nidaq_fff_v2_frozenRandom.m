function stimulusTrace = processStimInfo_LEDarena_Nidaq_fff_v2_frozenRandom(stimFile,nFrames)
% three random step sequences were created and shown to all flies either at
% ND 0.9 or ND 1.5, and at different speeds of change.
% Sequences stored in 'Pattern_fullfield_frozenRandom_seq1/2/3'.
% caution: not suitable for 10s steps, because only seq1 and seq2 were shown.
load(stimFile.name,'data','stimSeq','pat_id','patNames');
load('frozenRandomSeqs_0to15_6vals.mat');
seqs=[seq1;seq2*10;seq3*100];%multi by 10 and 100 to keep individual indentities
impVs=(10/24)*[1:24];

stimulusVoltage=data(:,2); 
% convert the voltage trace in a trace of stim frames
tolerance=0.02;%for voltage comparison
rawStimTrace=zeros(length(stimulusVoltage),1);
for iSample=1:length(stimulusVoltage)
    stimFrame=find(abs(impVs-stimulusVoltage(iSample))<tolerance);
    %correct for the case that the voltage rounds off to unexpected value
    if isempty(stimFrame) && iSample==1
        stimFrame=1; %the adapting zero also assigns voltage of the first frame
    elseif isempty(stimFrame) && iSample>1
%         stimVoltage=impStimVals(impVs==smoothStimVoltage(iSample-1));
        stimFrame=rawStimTrace(iSample-1);
    end
    rawStimTrace(iSample)=stimFrame;
end

% rearrange frozen seqs based on the pattern id seq
patInd=zeros(3,1);
for iPat=1:length(stimSeq)
    currPat=patNames{pat_id==stimSeq(iPat)};
    splitPat=split(currPat,{'q','.'});
    patInd(iPat)=str2double(splitPat{2});
end
currSeq=seqs(patInd,:);

% replace the frame numbers by stimVals
% stimIds=reshape(stimSeq,[numel(stimSeq),1]);
LEDchangeInds=find(diff(rawStimTrace)~=0)+1;
positiveChangeInds=find(diff(rawStimTrace)>0)+1;
changeDurs=[0;diff(positiveChangeInds)];%padding with 0 to represent first change Ind
seqChangeInds=positiveChangeInds(changeDurs==0 | changeDurs>3*mode(changeDurs));
if length(seqChangeInds)~=3
    fprintf('irregular trace - seq not identified correctly');
    return;
end
LEDstimTrace=zeros(length(rawStimTrace),1);
for iSeq=1:3
    startInd=seqChangeInds(iSeq);
    if iSeq<3
        endInd=LEDchangeInds(find(LEDchangeInds==seqChangeInds(iSeq+1))-1);
    else
        endInd=LEDchangeInds(end);
    end
    %take into account the hidden first step that occurs if the previous
    %stim ends with the second step and the following stim starts with the third
    if rawStimTrace(startInd)==3
        startInd=startInd-mode(changeDurs);
    end
    for iInd=startInd:endInd-1
        currentFrame=rawStimTrace(iInd);
        LEDstimTrace(iInd)=currSeq(iSeq,currentFrame);
    end
end

% downsample the trace to have one stim value per microscope frame
stimulusTrace = zeros(nFrames,1); % the final one
frameChangeInds=find(diff(data(:,1)))+1; %Where microscope frames change
% find out the smallest of nframes and frameChangeInds
usableFrames=min(nFrames,length(frameChangeInds));
for iFrame=1:usableFrames
    stimulusTrace(iFrame)=LEDstimTrace(frameChangeInds(iFrame));
end
end