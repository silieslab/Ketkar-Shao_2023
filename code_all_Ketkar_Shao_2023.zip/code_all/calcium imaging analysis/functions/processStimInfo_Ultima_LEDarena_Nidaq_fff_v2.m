function stimulusTrace = processStimInfo_Ultima_LEDarena_Nidaq_fff_v2(stimFile,nFrames,impVs,impStimVals)
% only for fff. Prerequisite: ON intensity level should be the last mention
% in the pattern name. e.g. __0to8.mk: 8 is the ON level.
load(stimFile.name,'data','stimSeq','pat_id','patNames');

%find LED levels corresponding to each pattern id
LEDlevel=zeros(length(patNames),1);
for iPat=1:length(patNames)
    splitPat=split(patNames{iPat},'to');
    splitPat2=split(splitPat{2},'.');
    LEDlevel(iPat)=str2double(splitPat2{1});
end

smoothStimVoltage=round(data(:,2)); % get rid of small fluctuations
% convert the voltage trace in a trace of 0s(OFF epochs) and 1s(adapting)
rawStimTrace=zeros(length(smoothStimVoltage),1);
for iSample=1:length(smoothStimVoltage)
    stimVoltage=impStimVals(impVs==smoothStimVoltage(iSample));
    %correct for the case that the voltage rounds off to unexpected value
    %special case: first Tseries of the day having low V at the start 
    if isempty(stimVoltage) && iSample==1
        stimVoltage=impStimVals(2);
    elseif isempty(stimVoltage) && iSample>1
%         stimVoltage=impStimVals(impVs==smoothStimVoltage(iSample-1));
        stimVoltage=rawStimTrace(iSample-1);
    end
    rawStimTrace(iSample)=stimVoltage;
end

% replace the 1s by adapting LED values
stimIds=reshape(stimSeq,[numel(stimSeq),1]);
stimChangeInds=find(diff(rawStimTrace)>0)+1;
LEDstimTrace=zeros(length(rawStimTrace),1);
for iEpoch=1:numel(stimChangeInds)
    currentLED=LEDlevel(pat_id==stimIds(iEpoch));
    if iEpoch==numel(stimChangeInds)
        LEDstimTrace(stimChangeInds(iEpoch):end)=...
        rawStimTrace(stimChangeInds(iEpoch):end) *currentLED;
    else
        LEDstimTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1)=...
        rawStimTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1) *currentLED;
    end
end

% downsample the trace to have one stim value per microscope frame
stimulusTrace = zeros(nFrames,1); % the final one
frameChangeInds=find(diff(data(:,1)))+1; %Where microscope frames change
% find out the smallest of nframes and frameChangeInds
usableFrames=min(nFrames,length(frameChangeInds));
for iFrame=1:usableFrames
    stimulusTrace(iFrame)=LEDstimTrace(frameChangeInds(iFrame));
end
end