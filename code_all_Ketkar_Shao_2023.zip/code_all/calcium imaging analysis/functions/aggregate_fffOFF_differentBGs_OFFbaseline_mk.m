function out = aggregate_fffOFF_differentBGs_OFFbaseline_mk(in)


% figure out how many epochs there are
s = in(1).istim;
unique_epochs_all = unique(s);  %count number of unique epoch numbers, still includes zero
unique_epochs=unique_epochs_all(unique_epochs_all~=0);

epochlength = zeros(length(in),1);
zeroInterleaveLength = zeros(length(in),1);
Combined_epochlength = zeros(length(in),1);
% loop over all of the stimuli to find the epochlength to be used:
for ii=1:length(in)
    s = in(ii).istim;
    % finding the actual epochs
    ds = diff(s); 

    % begining of the epoch, ie when the adapting interval starts
    % (which is the interstimulus blank period)
    binds = find(ds>0)+1; % finding the beginning of the adapting levels
    einds = find(ds<0)+1; % finding the beginning of the OFF step
% %     if binds(1)<einds(1) %adapting epoch rising edge comes first. not always the case
% %         binds(1)=[]; %to avoid problems with subtraction structure below.
% %     end
%     einds(end)=[]; % take away the last adaptingepoch because no OFF edge follows
%     binds(1)=[]; %take away the first OFF step because incomplete adaptingepoch precedes
    % find out which is shorter so that subtraction works out
    len = min(length(binds),length(einds));
    
    % duration of the zero epoch
    if binds(1)<einds(1) %adapting epoch rising edge comes first. not always the case
        dinds = binds(2:len)-einds(1:len-1); %to avoid problems with subtraction
    else
        dinds = binds(1:len)-einds(1:len);
    end
    zeroInterleaveLength(ii)=round(mean(dinds)); % epochlength and intervalLength should be exchanged in this special case
    
    % duration of the adapting epochs
    if binds(1)<einds(1) %adapting epoch rising edge comes first. not always the case
        ainds = einds(1:len)- binds(1:len);
    else
        ainds = einds(2:len)- binds(1:len - 1);
    end
    epochlength(ii) = round(mean(ainds));
    
    %automatically determine epoch duration, by looking for # of frames
    %between each step from a number (ie 8#) to 0. so includes both 000000
    %and 8888888 period for example
    Combined_epochlength(ii)=round(mean(diff(binds)));
    
end

% duration of the numbered epochs '555555555' or '22222222' 
epoch_dur = round(mean(epochlength));% if frame rate was ~10Hz and using 1 sec StandingStripe this value should be around 10.
% This duration of the zero epochs '00000000' 
zero_dur = round(mean(zeroInterleaveLength)); % if frame rate was ~10Hz and using 1 sec StandingStripe this value should be around 10.

% full duration include the adapting epoch,the follwing
% zero epoch and a part of following adapting epoch
full_dur = epoch_dur + round(1.25*zero_dur); % 1/4th of additional zero_dur after the zero dur
stimstruct = zeros(full_dur,1);
stimstruct(1:epoch_dur) = 1; %filling in the ones


rats = zeros([length(in),length(unique_epochs),full_dur]);
name = cell(length(in),1);


% extract the data as organized by epochs and store in for further processing
for ii=1:length(in)
%     ii
    % remove baseline
    iratio = in(ii).iratio;
    s = in(ii).istim;
    ds = diff(s);
    einds = find(ds<0)+1; %the beginning of the OFF step
    einds=einds(1:end-1); % omit the last one
    % extract OFF signals from the last 10% of each epoch (mean of this will be the baseline
    baselineDur=round(zero_dur/10);
    for mm = 1:length(einds)
        % The time period
        baseline_signal(:,mm) = iratio((einds(mm)+zero_dur-baselineDur):...
                                (einds(mm)+zero_dur));
    end

    % df/f
    baseline_signal(baseline_signal == 0) = NaN;
    baseline= nanmean(nanmean(baseline_signal)); %averaging over stimulus repititions
    d_iratio = iratio./baseline - 1;
%     d_iratio = iratio./mean(iratio) - 1; % when mean of the whole trace was the baseline
%     d_iratio = iratio;  %took out polyfit correction

    % finding the actual epochs
    binds = find(ds>0)+1;
    inds = binds(1:end-1); % omit last epoch
    
    epochs = s(inds); %stimulus values at those indices
    
%     pos = in(ii).ifstimpos1;
    
    for jj=1:length(unique_epochs) % unique stimulus values
        
        I = find(epochs==unique_epochs(jj)); %ms: take all the epochs
        bind = inds(I);
        
        %make variable to store the traces
        allEpochs = zeros(length(bind),full_dur);
        for mm = 1:length(bind)
            i_beginingOfTrace = bind(mm);
            i_endOfTrace = bind(mm) + full_dur -1;
            % extract full part of the trace that we want, includes the adapting epoch and following zero period
            allEpochs(mm,:) = d_iratio(i_beginingOfTrace:i_endOfTrace);
        end
        
        temp = mean(allEpochs,1);
        %maybe add back in a baseline subtraction here from the zero epoch
        %mean value, 
        %Check if this makes sense to do.  Another option would be to use
        %this baseline period to acutally calculate the dF/F
%         temp = temp- mean(temp(1:zero_dur));
  
        rats(ii,jj,:) = temp;
    end
    name{ii}=in(ii).name;

end

% save values into out variable and return to function.
out.rats = rats;
out.neuron = [in.cell];
out.flyID = [in.flyID];
out.name = name;
out.stimstruct = stimstruct;

end