function stimulusTrace = processStimInfo_Ultima_LEDarena_Nidaq_fff(stimFile,nFrames,impVs,impStimVals)
% not completely accurate for every recording. use v2
load(stimFile.name,'data','stimSeq','pat_id','patNames');
smoothStimVoltage=round(data(:,2));
stimulusTrace = zeros(nFrames,1);
frameChangeInds=find(diff(data(:,1)))+1; %Where microscope frames change
% first assign impStimVals that pairs with current voltage.
% e.g. 1 to adapting luminance and 0 to OFF step
for iFrame=1:nFrames
    stimVoltage=smoothStimVoltage(frameChangeInds(iFrame));
    stimulusTrace(iFrame)=impStimVals(impVs==stimVoltage);
end

%find LED levels corresponding to each pattern id
LEDlevel=zeros(length(patNames),1);
for iPat=1:length(patNames)
    splitPat=split(patNames{iPat},'to');
    splitPat2=split(splitPat{2},'.');
    LEDlevel(iPat)=str2double(splitPat2{1});
end

%now incorporate LED level of the adapting luminance
stimIds=reshape(stimSeq,[numel(stimSeq),1]); %straightening the matrix
stimChangeInds=find(diff(stimulusTrace)>0)+1;
for iEpoch=1:numel(stimChangeInds)
    currentLED=LEDlevel(pat_id==stimIds(iEpoch));
    if iEpoch==numel(stimChangeInds)
        stimulusTrace(stimChangeInds(iEpoch):end)=...
        stimulusTrace(stimChangeInds(iEpoch):end) *currentLED;
    else
        stimulusTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1)=...
        stimulusTrace(stimChangeInds(iEpoch):stimChangeInds(iEpoch+1)-1) *currentLED;
    end
end
end