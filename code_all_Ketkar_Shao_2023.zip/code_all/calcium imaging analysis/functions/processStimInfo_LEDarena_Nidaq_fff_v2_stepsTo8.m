function stimulusTrace = processStimInfo_LEDarena_Nidaq_fff_v2_stepsTo8(stimFile,nFrames,impVs,impStimVals)
% 'Ultima' dropped from the function name because now working with
% investigator and the microscope doesn't matter for the analysis.
% stepsTo8 is a mixture of ON and OFF steps, for characterizing L2.
load(stimFile.name,'data','stimSeq','pat_id','patNames');

%find LED levels (other than 8) corresponding to each pattern id
LEDlevel=zeros(length(patNames),1);
for iPat=1:length(patNames)
    splitPat=split(patNames{iPat},{'_','to','.'});
    if splitPat{3}=='8'
        LEDlevel(iPat)=str2double(splitPat{4});
    else
        LEDlevel(iPat)=str2double(splitPat{3});
    end
end

smoothStimVoltage=round(data(:,2)); % get rid of small fluctuations
% convert the voltage trace in a trace of 8s(common epochs) and 1s(steps)
rawStimTrace=zeros(length(smoothStimVoltage),1);
for iSample=1:length(smoothStimVoltage)
    stimVoltage=impStimVals(impVs==smoothStimVoltage(iSample));
    %correct for the case that the voltage rounds off to unexpected value
    %special case: first Tseries of the day having low V at the start 
    if isempty(stimVoltage) && iSample==1
        stimVoltage=0; %to distinguish the low V from that of the 8 epoch
    elseif isempty(stimVoltage) && iSample>1
%         stimVoltage=impStimVals(impVs==smoothStimVoltage(iSample-1));
        stimVoltage=rawStimTrace(iSample-1);
    end
    rawStimTrace(iSample)=stimVoltage;
end

% replace the 1s by other-than-8 LED values
stimIds=reshape(stimSeq,[numel(stimSeq),1]);
stimChangeInds=find(diff(rawStimTrace)>0)+1;
stepStartInds=find(diff(rawStimTrace)<0)+1;
LEDstimTrace=zeros(length(rawStimTrace),1);
for iEpoch=1:numel(stimChangeInds)
    %assign the 8s as they are
    LEDstimTrace(stimChangeInds(iEpoch):stepStartInds(iEpoch)-1)=...
        rawStimTrace(stimChangeInds(iEpoch):stepStartInds(iEpoch)-1);
    currentLED=LEDlevel(pat_id==stimIds(iEpoch));
    if iEpoch==numel(stimChangeInds)
        LEDstimTrace(stepStartInds(iEpoch):end)=...
        rawStimTrace(stepStartInds(iEpoch):end) *currentLED;
    else
        LEDstimTrace(stepStartInds(iEpoch):stimChangeInds(iEpoch+1)-1)=...
        rawStimTrace(stepStartInds(iEpoch):stimChangeInds(iEpoch+1)-1) *currentLED;
    end
end

% downsample the trace to have one stim value per microscope frame
stimulusTrace = zeros(nFrames,1); % the final one
frameChangeInds=find(diff(data(:,1)))+1; %Where microscope frames change
% find out the smallest of nframes and frameChangeInds
usableFrames=min(nFrames,length(frameChangeInds));
for iFrame=1:usableFrames
    stimulusTrace(iFrame)=LEDstimTrace(frameChangeInds(iFrame));
end
end