function stimulusTrace = processStimInfo_Ultima_LEDarena(stimFile,nFrames)

load(stimFile.name);
stimulusTrace = zeros(nFrames,1);
for iFrame=1:nFrames
    recordedFrameInd=find(arduino_timings.imaging_frames==iFrame,1);
    if (~isempty(recordedFrameInd))
        stimulusTrace(iFrame)=arduino_timings.ledLevel(recordedFrameInd);
    elseif (isempty(recordedFrameInd))
        if iFrame==1
            stimulusTrace(iFrame)=0;
        else
            stimulusTrace(iFrame)=stimulusTrace(iFrame-1);
        end
    end
end

end