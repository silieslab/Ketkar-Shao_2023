%% Analysis of full-field flashes

clearvars;
% close all;

%% specify CONSTANTS
stimulusCode = 'frozenRandom_5s'; 
%frozenRandom_0.5s,frozenRandom_1s,frozenRandom_5s,frozenRandom_10s
driverCode = 'UASGCaMP6F_L221DhhGal4_cross_to_UASGCaMP6F'; % 'UASGCaMP6F_L3MH56Gal4_cross_to_w'
filterCode = 0.9; %0.9,1.5
REGION = 'AT';  % AT for axon terminals. Some experiments may require imaging soma or dendrites instead.
genotype_string = ['L2 >> GCaMP6f']; %L2/L3

%% add paths of the code and the pData
addpath(genpath('Y:\MadhuraK\WD Elements drive_2P code\2P analysis codes\Advanced_2P_processing'));
pDataPath='Y:\MadhuraK\WD Elements drive_2P code\2P analysis codes\Advanced_2P_processing\pData';

%% find processed data files for specified genotype and 5s fff stimulus
% The spreadsheet Summary_database_mk.xlsx contains information for each processed data file.
% This section identifies the files that have matching stimulus and driver line information. 
inds_summaryFile  = database_select_samples_mk(stimulusCode,driverCode,filterCode,REGION);

%% read data from those files and aggregate for stimulus epochs
cd(pDataPath);

% create structures for each neuron
neurStructs = create_neuron_structure_all_ks(inds_summaryFile);

% interpolate data to bring it in the 10Hz format
neurData = load_neuron_data10Hz_byRegion_mk(neurStructs,pDataPath);

% aggregate data by stimulus epochs
data = aggregate_fff_frozenRandom_zerobaseline_mk(neurData);

% save as processed data
save(['Y:\MadhuraK\WD Elements drive_2P code\2P analysis codes\Advanced_2P_processing\advanced pData\L2\processedData_ND',...
 num2str(filterCode),'_',stimulusCode,'.mat'],'neurData','data');
%% Select/discard ROIs based on correlation with stimulus
% select those in neg correlation with all individual stimulus categories
corrThresh=0.1;

% start with all the data, process the negatively correlated ones (by value Q)
cur_mat = data.rats;
cur_IDs = data.flyID;
% mean_res = mean(cur_mat,1); %was correlating with the mean before
% Q = corr(mean_res',cur_mat');

corrSigns=zeros(size(cur_mat,1),size(cur_mat,2)); %assign +1 for positive, -1 for negative
% inds=270:340; %fraction of the traces where the correlation should be tested
for iStim = 1:size(cur_mat,2) 
    epochRats = squeeze(cur_mat(:,iStim,:));
%     [x,m,e] = mean_cat_full(epochRats,1,cur_IDs); %m=mean; e=std
    
    stimulus = mean(squeeze(data.stimstruct(:,iStim,:)),1);%only for correlation purpose
% %     Q = corr(stimulus(inds),epochRats(:,inds)'); % when entire trace may not show high correlation
    Q = corr(stimulus',epochRats');
    
    %positive correlation with stimulus    
    corrSigns(:,iStim) = (Q>corrThresh);
    if sum(corrSigns(:,iStim))>0 % at least one inverted cell exists
        cur_mat_pos = epochRats(logical(corrSigns(:,iStim)),:);
    end

    %negative correlation with stimulus
    corrSigns(:,iStim) =  corrSigns(:,iStim)+((Q<-corrThresh)*-1)';
    if sum(corrSigns(:,iStim)==-1)>0 %if 'normal' cells exist
        cur_mat_neg = epochRats(corrSigns(:,iStim)==-1,:);
    end
    
    %plot individual ROIs to verify the selection creterion
    figure; hold on
    plot(cur_mat_neg')
    if sum(corrSigns(:,iStim)==1)>0 % at least one inverted cell exists
        figure; hold on
        plot(cur_mat_pos')
    end

end
% discard those in different(opposite) correlations with individual stimulus categories
faultInds=(sum(corrSigns,2)~=(size(corrSigns,2)*-1)) & ...
    (sum(corrSigns,2)~=size(corrSigns,2)); 
% faultInds=(sum(corrSigns,2)~=(size(corrSigns,2)*-1)) & ...
%     (sum(corrSigns,2)~=size(corrSigns,2)); % & (prod(corrSigns,2)~=0);
corrSignsCorrected=corrSigns;
corrSignsCorrected(logical(faultInds),:)=zeros(sum(faultInds),size(corrSigns,2));

%% extract relevant stats and plot
%declare constants and variables
iRATE = 10; %rate at which data are interpolated
cur_t = (1:size(cur_mat,3))/iRATE;
stimlabels=[1 2 3];% 

flyMeanTraces=[];
%open figures for plotting inside the loop
f1=figure; %mean across flies, neg corr
f2=figure; %mean across flies, pos corr
f3=figure; %mean across ROIs, individual flies, neg corr
f4=figure; %mean across all ROIs, neg corr
for iStim = 1:size(cur_mat,2) 
    epochRats = squeeze(cur_mat(:,iStim,:));
%     [x,m,e] = mean_cat_full(epochRats,1,cur_IDs); %m=mean; e=std, when ignoring corr
     % x is the mean across ROIs for each fly

    %positive correlation, based on correlation with the 1st stim
    if sum(corrSignsCorrected(:,1)==1)>0 % at least one inverted cell exists
        cur_mat_pos = epochRats(corrSignsCorrected(:,1)==1,:);
        cur_IDs_pos = cur_IDs(corrSignsCorrected(:,1)==1);
        %calculating means across flies
        [x_pos,m_pos,e_pos] = mean_cat_full(cur_mat_pos,1,cur_IDs_pos);
        %calculating the max for each trace
        max_pos = max(x_pos,[],2)-1;
    end
    %negative correlation, based on correlation with the 1st stim
    if sum(corrSignsCorrected(:,1)==-1)>0 % at least one normal cell exists
        cur_mat_neg = epochRats(corrSignsCorrected(:,1)==-1,:);
        cur_IDs_neg = cur_IDs(corrSignsCorrected(:,1)==-1);
        %calculating means across flies
        [x_neg,m_neg,e_neg] = mean_cat_full(cur_mat_neg,1,cur_IDs_neg);
        %calculating the max for each trace
        max_neg = max(x_neg,[],2);
        flyMeanTraces=cat(3,flyMeanTraces,x_neg);
    end
    
    %plot 'normal' mean across flies
    figure(f1); %hold on
%     subplot(1,size(cur_mat,2),iStim);
    subplot(size(cur_mat,2) ,1,iStim)
    h1(iStim) = plot_err_patch_v2(cur_t,m_neg,e_neg,...
        [0 0 iStim/size(cur_mat,2)],[0 0 (iStim-0.5)/size(cur_mat,2)]);
%     title(['background LED ',num2str(stimlabels(iStim))]);
    plot(cur_t, mean(squeeze(data.stimstruct(:,iStim,:)),1)*0.1 +1.4, 'k')
    ylim([-0.8 3.0]);
    ylabel('dF/F');
    xlabel('time (s)');
    sgtitle([genotype_string ', neg corr, mean across flies']);

    %plot 'inverted' mean across flies, if exists
    if sum(corrSignsCorrected(:,1)==1)>1 %just one ROI won't allow calculating SEM
        figure(f2); hold on
        subplot(1,size(cur_mat,2),iStim);
        plot_err_patch_v2(cur_t,m_pos,e_pos,[0 iStim/size(cur_mat,2) 0],[0 (iStim-0.5)/size(cur_mat,2) 0]);
        title(['sequence ',num2str(stimlabels(iStim))]);
    end
    
    
    % plot mean traces of individual flies
    figure(f3);hold on
%     subplot(1,size(cur_mat,2) ,iStim)
    subplot(size(cur_mat,2) ,1,iStim)
    plot(cur_t,x_neg')
    title(['sequence ',num2str(stimlabels(iStim))])
    ylabel('dF/F');
    xlabel('time (s)');
    sgtitle([genotype_string ', neg corr, individual fly means'])
    
    % plot mean across all negatively correlated ROIs
    mROI_neg = mean(cur_mat_neg);
    eROI_neg = std(cur_mat_neg,[],1)/sqrt(size(cur_mat_neg,1)); %S.E.M
    figure(f4); hold on
%     subplot(1,size(cur_mat,2) ,iStim)
%     subplot(size(cur_mat,2) ,1,iStim)
    plot_err_patch_v2(cur_t,mROI_neg,eROI_neg,[0 0 iStim/size(cur_mat,2)],[0  0 (iStim-0.5)/size(cur_mat,2)]);
%     title(['background LED ',num2str(stimlabels(iStim))]);
    sgtitle([genotype_string ', neg corr, mean across ROIs']);
%     plot(cur_t, data.stimstruct*0.2 +1.6)
    ylim([-0.8 3.0]); 
end
figure(f1)
legend(h1(:),sprintf('N = %d ( %d )',size(x_neg,1),size(cur_mat_neg,1)),...
'location','northeast');

% save the processed variables
% save(['Y:\MadhuraK\WD Elements drive_2P code\2P analysis codes\Advanced_2P_processing\advanced pData\L2\',...
%     'quantification_ND',num2str(filterCode),'_',stimulusCode,'.mat'],'OFFcalmean','OFFcalSEM','OFFpeakmean',...
%     'OFFpeakSEM','adaptcalmean','adaptcalSEM','flyMeanTraces');
%% Discard only based on correlation with that stimulus; not all stimuli
%declare constants and variables
iRATE = 10; %rate at which data are interpolated
cur_t = (1:size(cur_mat,3))/iRATE;
stimlabels=[1 2 3];% 

flyMeanTraces=[];
%open figures for plotting inside the loop
f1=figure; %mean across flies, neg corr
f2=figure; %mean across flies, pos corr
f3=figure; %mean across ROIs, individual flies, neg corr
f4=figure; %mean across all ROIs, neg corr
for iStim = 1:size(cur_mat,2) 
    epochRats = squeeze(cur_mat(:,iStim,:));
%     [x,m,e] = mean_cat_full(epochRats,1,cur_IDs); %m=mean; e=std, when ignoring corr
     % x is the mean across ROIs for each fly

    %positive correlation, based on correlation with the 1st stim
    if sum(corrSigns(:,1)==1)>0 % at least one inverted cell exists
        cur_mat_pos = epochRats(corrSigns(:,1)==1,:);
        cur_IDs_pos = cur_IDs(corrSigns(:,1)==1);
        %calculating means across flies
        [x_pos,m_pos,e_pos] = mean_cat_full(cur_mat_pos,1,cur_IDs_pos);
        %calculating the max for each trace
        max_pos = max(x_pos,[],2)-1;
    end
    %negative correlation, based on correlation with the 1st stim
    if sum(corrSigns(:,1)==-1)>0 % at least one normal cell exists
        cur_mat_neg = epochRats(corrSigns(:,1)==-1,:);
        cur_IDs_neg = cur_IDs(corrSigns(:,1)==-1);
        %calculating means across flies
        [x_neg,m_neg,e_neg] = mean_cat_full(cur_mat_neg,1,cur_IDs_neg);
        %calculating the max for each trace
        max_neg = max(x_neg,[],2);
        flyMeanTraces=cat(3,flyMeanTraces,x_neg);
    end
    
    %plot 'normal' mean across flies
    figure(f1); %hold on
%     subplot(1,size(cur_mat,2),iStim);
    subplot(size(cur_mat,2) ,1,iStim)
    h1(iStim) = plot_err_patch_v2(cur_t,m_neg,e_neg,...
        [0 0 iStim/size(cur_mat,2)],[0 0 (iStim-0.5)/size(cur_mat,2)]);
%     title(['background LED ',num2str(stimlabels(iStim))]);
    plot(cur_t, mean(squeeze(data.stimstruct(:,iStim,:)),1)*0.1 +1.4, 'k')
    ylim([-0.8 3.0]);
    ylabel('dF/F');
    xlabel('time (s)');
    sgtitle([genotype_string ', neg corr, mean across flies']);

    %plot 'inverted' mean across flies, if exists
    if sum(corrSigns(:,1)==1)>1 %just one ROI won't allow calculating SEM
        figure(f2); hold on
        subplot(1,size(cur_mat,2),iStim);
        plot_err_patch_v2(cur_t,m_pos,e_pos,[0 iStim/size(cur_mat,2) 0],[0 (iStim-0.5)/size(cur_mat,2) 0]);
        title(['sequence ',num2str(stimlabels(iStim))]);
    end
    
    
    % plot mean traces of individual flies
    figure(f3);hold on
%     subplot(1,size(cur_mat,2) ,iStim)
    subplot(size(cur_mat,2) ,1,iStim)
    plot(cur_t,x_neg')
    title(['sequence ',num2str(stimlabels(iStim))])
    ylabel('dF/F');
    xlabel('time (s)');
    sgtitle([genotype_string ', neg corr, individual fly means'])
    
    % plot mean across all negatively correlated ROIs
    mROI_neg = mean(cur_mat_neg);
    eROI_neg = std(cur_mat_neg,[],1)/sqrt(size(cur_mat_neg,1)); %S.E.M
    figure(f4); hold on
%     subplot(1,size(cur_mat,2) ,iStim)
%     subplot(size(cur_mat,2) ,1,iStim)
    plot_err_patch_v2(cur_t,mROI_neg,eROI_neg,[0 0 iStim/size(cur_mat,2)],[0  0 (iStim-0.5)/size(cur_mat,2)]);
%     title(['background LED ',num2str(stimlabels(iStim))]);
    sgtitle([genotype_string ', neg corr, mean across ROIs']);
%     plot(cur_t, data.stimstruct*0.2 +1.6)
    ylim([-0.8 3.0]); 
end
figure(f1)
legend(h1(:),sprintf('N = %d ( %d )',size(x_neg,1),size(cur_mat_neg,1)),...
'location','northeast');
