%% 2p pre-processing: from motion correction to ROI data extraction.

% clear previous variables and create new hardcoded ones if any
clearvars;
% stimulus controller DAC output variables:
impVs=[5,10]; %round-off controller output values that correspond to static onset,motion onset and 
% (if present) interval onset. [5,10] for fff.
% will be 1/97 and 10 for single OFF edge (first frame, last frame).
% Visualize controller output trace before aligning new stimuli.
impStimVals=[8,1]; % [1,0];[8,1];%values (high,low) corresponding to impVs. for ON flash, these will be [0,1],
% unless same patterns are used by showing frames in reverse order (then impVs=[10,5], but verify).
% when using motion patterns, durMotion could be set to high regardless of contrast.
% this var does not differentiate between intensities or any other
% distinguishing parameters yet. That happens inside the stim alignment function.

existBLseries=1; %if a baseline sequence was recorded before the stimulated sequence
%% get filename and file type to read
dirPath=uigetdir(pwd, 'Select the series folder');
cd(dirPath); 
folder = dir('*.xml');
filename = [folder.name];
if isempty(filename)
    xmlDir = dir('T*');
    xmlDirName = xmlDir([xmlDir.isdir]).name;
    cd(xmlDirName)
    folder = dir('*.xml');
    filename = [folder.name];
end
filetype = 'xml';
%% read metadata to know dimensions of the dataset
[imagingInfo, scanInfo] = getXmlInfo(filename);%information for every single frame, as well as scan settings
nFrames = numel(imagingInfo.stimulusFrames); % Number of stimulated frames.
BLFrames = numel(imagingInfo.baselineFrames); % Number of stimulated frames.
height = str2double(scanInfo.linesPerFrame);% lines per frame.
width = str2double(scanInfo.pixelsPerLine);% pixels per line.
stimulusFrames = [imagingInfo.stimulusFrames{:}];
xml=scanInfo; % for saving
%% Motion correction/ image alignment 
% read TIFF images of stimulated sequence and baseline sequence (if exists)
% in separate matrices
% close all
if existBLseries
    imageArray = readTwoPhotonTimeSeries(filename, imagingInfo, 2);
    imageArrayBL = readTwoPhotonTimeSeries(filename, imagingInfo, 1);
else
    imageArray = readTwoPhotonTimeSeries(filename, imagingInfo, 1);
end

% make reference image of maximum intensity projections from first 30 frames and visualize
refFrame = max(imageArray(:,:,1:30), [], 3); 
figure;
imagesc(refFrame);
colorbar;

% align each frame by maximizing image crosscorrelation in the fourier space
alignedImArray=fourierCrossCorrelAlignment_mk(imageArray,refFrame,filetype); 

% align the baseline sequence
if existBLseries
    alignedBLArray=fourierCrossCorrelAlignment_mk(imageArrayBL,refFrame,filetype);
end

% visualize the effects of alignment
subplot(211)
meanFraw=mean(imageArray,3);% mean raw images
imagesc(meanFraw);
title('Mean image from RAW dataset')
colorbar;
subplot(212)
meanFaligned=mean(alignedImArray,3);% mean aligned image (note the mean across time dimension)
imagesc(meanFaligned);
colorbar;
title('Mean image from ALIGNED dataset')

%% plot simple image statistics, remove any trends if necessary
% close all
meanFaligned2=mean(mean(alignedImArray));% mean fluorescence time series (note the mean across all pixels of a frame)
figure;
plot(squeeze(meanFaligned2));

% If the meanfluorescence gradually increases or decreases over time, you
% may consider removing this trend
detrendedIm=detrend3(alignedImArray);
meanFdetrended=mean(mean(detrendedIm));% mean fluorescence time series after detrending
% compare the new time series by plotting it on the same graph
hold on
plot(squeeze(meanFdetrended));
xlabel('time frames'); % can you add a unit?
ylabel('mean fluorescence (arbitrary units)')
legend('aligned only','aligned and detrended')

%% make a movie of aligned images
close all
frameRate=15; % change to fit your taste
makeTimeSeriesMovie_mk(alignedImArray(:,:,900:1100),'aligned_series_16bit_framerate15', 'mp4', 15);

%% Process stimulus file
cd(dirPath)
stim_file = dir('*mk*.mat');
% stimulusTrace = processStimInfo(stim_file,nFrames); %lightcrafter stimuli
% stimulusTrace = processStimInfo_Ultima_LEDarena(stim_file,nFrames);
% stimulusTrace = processStimInfo_Ultima_LEDarena_Nidaq_fff_v2(stim_file,nFrames,impVs,impStimVals);
% stimulusTrace = processStimInfo_LEDarena_Nidaq_fff_v2_stepsTo8(stim_file,nFrames,impVs,impStimVals);
stimulusTrace = processStimInfo_LEDarena_Nidaq_fff_v2_frozenRandom_10s(stim_file,nFrames);
% stimulusTrace = processStimInfo_Ultima_LEDarena_Nidaq_singleMotionPair(stim_file,nFrames,impVs,impStimVals);

%% ROI selection
% The average image is mostly used as a representative image since it will show us
% the neuron structures and won't have noise (due to averaging over many images)
avgImage = squeeze( sum( alignedImArray,3 ) ) / nFrames; % The average image 
Image_max = max( alignedImArray,[],3 ) ; % The max image

figH_ROI = figure();
axesH_ROI = axes();
imagesc( avgImage , 'parent' , axesH_ROI );
title('Press Double click to confirm ROI after selection, ENTER to finish selection')

done = 0; 
ROInum = 0;
roi_colors = colormap('lines');
colormap gray
while ( ~done )
    
    ROInum = ROInum + 1 ;
    masks{ ROInum } = roipoly;
    % if mistakenly clicked 1 or 2 points
    if isempty(find(masks{ ROInum }))
        warning('Single point clicked, not taking ROI')
        continue
    end 
    currentColor = roi_colors(ROInum,:);
    alphamask( masks{ ROInum } , ...
        [currentColor(1) currentColor(2) currentColor(3)] , 0.33 );
    hold on ;
    done = waitforbuttonpress;
end
nMasks = ROInum;

%% ------- Select background region --------
figH_BG = figure(); 
axesH_BG = axes();
imagesc( avgImage , 'parent' , axesH_BG );
colormap gray;
title('select background region');
BGMask = roipoly;

%% ------- Extract ROI signals --------

% We need to extract signals one by one
maskSignals = zeros(nMasks,nFrames);
dSignals = zeros(size(maskSignals));
for iMask = 1:nMasks
    currMask = masks{iMask};  
    for iFrame = 1:nFrames
        currFrame = alignedImArray(:,:,iFrame);
        maskSignals(iMask,iFrame) = mean(currFrame(currMask));
        dSignals(iMask,iFrame) = maskSignals(iMask,iFrame) - mean(currFrame(BGMask)); %background subtracted
    end
%     [row,col] = ind2sub(size(currMask),find(currMask));
%     maskSignals1Line(iMask,:) = ...
%         squeeze(mean(alignedImArray(row,col,:),[1,2]));
end

figure;
title('ROI signals')
plot(stimulusTrace'*10 -500,'-k','LineWidth',1.5,... %*max(max(maskSignals))
    'DisplayName','stimulus')
legend()
hold on;
plot(dSignals','LineWidth',1.5)
xlabel('Frames')
ylabel('Background-subtracted raw signals');%('Raw signal (AU)')

% extract baseline signal from the first sequence
if existBLseries
    BLSignals = zeros(nMasks,BLFrames);
    BL_dSignals = zeros(size(BLSignals));
    for iMask = 1:nMasks
        currMask = masks{iMask};  
        for iFrame = 1:BLFrames
            currFrame = alignedBLArray(:,:,iFrame);
            BLSignals(iMask,iFrame) = mean(currFrame(currMask));
            BL_dSignals(iMask,iFrame) = BLSignals(iMask,iFrame) - mean(currFrame(BGMask)); %background subtracted
        end
    end
end
%% correct stimulusTrace considering acquisition lag
% only for the experiment until acquisition system is corrected
% manually select a best ROI and adjust the number-of-frames discrepancy
roiNum=5;
% plot just this ROI
figure;
plot(stimulusTrace'*50,'--k','LineWidth',3,... 
    'DisplayName','stimulus')
hold on;
plot(maskSignals(roiNum,:)','LineWidth',1.5)

lag=input('enter the lag, positive if response lags the stimulus'); %in frames
if lag>=0
    stimulusTraceAdjusted=[zeros(lag,1);stimulusTrace(1:end-lag,1)];
else
    stimulusTraceAdjusted=[stimulusTrace(1-lag:end,1);zeros(-lag,1)];
end
% verify
figure;
plot(stimulusTraceAdjusted'*50,'--k','LineWidth',3,... 
    'DisplayName','stimulus')
hold on;
plot(dSignals(roiNum,:)','LineWidth',1.5)

%% ------- Save data --------
cd(dirPath)

% Create a data structure for saving necessary data
processedData = struct();
processedData.xml=xml;
processedData.avgImage = avgImage;
processedData.masks = masks;
processedData.signals = maskSignals;
processedData.dSignals=dSignals;
if existBLseries
    processedData.BLsignals = BLSignals;
    processedData.BL_dSignals=BL_dSignals;
end
% processedData.stimTrace = stimulusTraceAdjusted;
processedData.stimTrace = stimulusTrace;

%Save the data
filenameStr=split(stim_file.name,'.');
splitName=split(filenameStr{1},'_');
TSeriesStr=splitName{3};
stringTimeSeriesPath = split(dirPath,filesep);
flyFolderName = stringTimeSeriesPath{4}; %hardcoding. Check the splitting results when data location changes
saveName = sprintf('%s_%s_pdata.mat',flyFolderName,TSeriesStr);
save(saveName,'processedData')
