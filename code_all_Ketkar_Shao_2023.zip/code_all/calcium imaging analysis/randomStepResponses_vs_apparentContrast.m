%% Extract L2 step responses from the frozen random dataset (ND 0.9, ND 1.5)
% and plot against different definitions of contrast

clearvars;
%% constants
ndNums=[0.9, 1.5];
ndNames={'ND0.9','ND1.5'};
stepDurs=[0.5,1,5,10];% %in s. all ndNums*stepDur combinations tested. 0.5 dur analyse separately
stepDurNames={'0.5','1','5','10'};% %strings
% responseAvgWindow=4:6;%{4:6;6:8;6:8;6:8}; %data points to be averaged relative to the stimulus switch.
                        % Determined by manual observation of peak occurrence.
                        % now replaced by averaging around respective max value
baseAvgWindow=-2:0; % average over 3 datapoints prior to switch to obtain baseline.
meanStimVal=(0+1+2+4+8+15)/6; %approximation used for apparent contrast in all 3 sequences

%% load data and extract stimulus and response features
% added later but unnecessary: detrend response traces, rescale them between -1 and 1
% also added: save prior luminance
datapath='Y:\MadhuraK\WD Elements drive_2P code\2P analysis codes\Advanced_2P_processing\advanced pData\L2\';
weberConts=cell(length(ndNums),length(stepDurs));
apparentConts=cell(length(ndNums),length(stepDurs));
bgLums=cell(length(ndNums),length(stepDurs));
stepResponses=cell(length(ndNums),length(stepDurs));
peakResponses=cell(length(ndNums),length(stepDurs)); %with respect to the mean calcium
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        load([datapath,'processedData_',ndNames{iND},'_frozenRandom_',stepDurNames{iStepDur},'s.mat']);
        wContsTemp=cell(length(data.neuron),1);
        aContsTemp=cell(length(data.neuron),1);
        bgLumsTemp=cell(length(data.neuron),1);
        stepResTemp=cell(length(data.neuron),1);
        peakResTemp=cell(length(data.neuron),1);
        for iNeuron=1:length(data.neuron)
            wContsTemp{iNeuron}=[];
            aContsTemp{iNeuron}=[];
            bgLumsTemp{iNeuron}=[];
            stepResTemp{iNeuron}=[];
            peakResTemp{iNeuron}=[];
            for iSequence=1:size(data.stimstruct,2)
                % stimulus features
                currSequence=squeeze(data.stimstruct(iNeuron,iSequence,:));
                switchPoints=find(diff(currSequence));%indices represent end point of each step
%                 switchPoints(end)=[]; %omit last one due to length issues.
%                 now wrking around it using an if clause.
                stimVals=[currSequence(1);currSequence(switchPoints+1)];
%                 meanVal=mean(stimVals); %before used for apparent contrast,
%                  but changes across the three sequences
                wContsTemp{iNeuron}=[wContsTemp{iNeuron};diff(stimVals)./stimVals(1:end-1)];
                aContsTemp{iNeuron}=[aContsTemp{iNeuron};diff(stimVals)./meanStimVal];
                bgLumsTemp{iNeuron}=[bgLumsTemp{iNeuron};stimVals(1:end-1)];
                % response features
%                 currResponse_detrend=detrend(squeeze(data.rats(iNeuron,iSequence,:)));
%                 currResponse=rescale(currResponse_detrend,-1,1);
                currResponse=rescale(squeeze(data.rats(iNeuron,iSequence,:)),-0.5,0.5);
%                 meanCal=mean(currResponse); %take mean of the pre-sequence (0) epoch instead
                meanCal=mean(currSequence(1:switchPoints(1)));
                stepR=zeros(length(switchPoints),1);
                peakR=zeros(length(switchPoints),1);
                for iSwitch=1:length(switchPoints)
                    preCal=mean(currResponse(switchPoints(iSwitch)+baseAvgWindow));
                    if switchPoints(iSwitch)+8<=length(currResponse)%8: #datapoints that generally include max value
                        % identify ON and OFF changes and take min/max accordingly
                        if stimVals(iSwitch+1)<stimVals(iSwitch) %OFF step
                            [~,maxInd]=max(currResponse(switchPoints(iSwitch)+1:switchPoints(iSwitch)+8));
                        elseif stimVals(iSwitch+1)>stimVals(iSwitch) %ON step
                            [~,maxInd]=min(currResponse(switchPoints(iSwitch)+1:switchPoints(iSwitch)+8));
                        end
                        postCal=mean(currResponse(switchPoints(iSwitch)+maxInd-1:switchPoints(iSwitch)+maxInd(1)+1));
                        stepR(iSwitch)=postCal-preCal;
                        peakR(iSwitch)=postCal-meanCal;
                    end
                end
                stepResTemp{iNeuron}=[stepResTemp{iNeuron};stepR];
                peakResTemp{iNeuron}=[peakResTemp{iNeuron};peakR];
            end
        end
        weberConts{iND,iStepDur}=wContsTemp;
        apparentConts{iND,iStepDur}=aContsTemp;
        bgLums{iND,iStepDur}=bgLumsTemp;
        stepResponses{iND,iStepDur}=stepResTemp;
        peakResponses{iND,iStepDur}=peakResTemp;
    end
end

%% scatter all responses across Weber and apparent contrasts per ND, per stepDur
% turns out very noisy
% step responses vs Weber contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(weberConts{iND,iStepDur})
            scatter(weberConts{iND,iStepDur}{iNeuron},stepResponses{iND,iStepDur}{iNeuron})
            xlabel('Weber contrast')
            ylabel('L2 step response (dF/F)')
            title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
            xlim([-1.25 0])% when restricting to negative contrasts
        end
    end
end

% step response vs apparent contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            scatter(apparentConts{iND,iStepDur}{iNeuron},stepResponses{iND,iStepDur}{iNeuron})
            xlabel('Apparent contrast')
            ylabel('L2 step response (dF/F)')
            title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
            xlim([-4 0])% when restricting to negative contrasts
        end
    end
end

% peak responses vs Weber contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(weberConts{iND,iStepDur})
            scatter(weberConts{iND,iStepDur}{iNeuron},peakResponses{iND,iStepDur}{iNeuron})
            xlabel('Weber contrast')
            ylabel('L2 peak response (dF/F)')
            title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
            xlim([-1.25 0])% when restricting to negative contrasts
        end
    end
end

% peak response vs apparent contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            scatter(apparentConts{iND,iStepDur}{iNeuron},peakResponses{iND,iStepDur}{iNeuron})
            xlabel('Apparent contrast')
            ylabel('L2 peak response (dF/F)')
            title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
            xlim([-4 0])% when restricting to negative contrasts
        end
    end
end
%% extract responses to same contrast and compute stats over neurons
uniqueWeber=unique(weberConts{1,1}{1});
uniqueApparent=unique(apparentConts{1,1}{1});
%for step responses
meanStepRperWeber=zeros(length(ndNums),length(stepDurs),length(uniqueWeber));
meanStepRperApparent=zeros(length(ndNums),length(stepDurs),length(uniqueApparent));
semStepRperWeber=zeros(length(ndNums),length(stepDurs),length(uniqueWeber));
semStepRperApparent=zeros(length(ndNums),length(stepDurs),length(uniqueApparent));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % extract for Weber contrasts
        for iWeber=1:length(uniqueWeber)
            meanPerNeuron=zeros(length(weberConts{iND,iStepDur}),1);
            for iNeuron=1:length(weberConts{iND,iStepDur})
                meanPerNeuron(iNeuron)=nanmean(stepResponses{iND,iStepDur}{iNeuron}...
                    (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber)));
            end
            meanStepRperWeber(iND,iStepDur,iWeber)=nanmean(meanPerNeuron);
            semStepRperWeber(iND,iStepDur,iWeber)=nanstd(meanPerNeuron)./sqrt(length(meanPerNeuron));
        end
        % extract for apparent contrasts
        for iApparent=1:length(uniqueApparent)
            meanPerNeuron=zeros(length(apparentConts{iND,iStepDur}),1);
            for iNeuron=1:length(apparentConts{iND,iStepDur})
                meanPerNeuron(iNeuron)=nanmean(stepResponses{iND,iStepDur}{iNeuron}...
                    (apparentConts{iND,iStepDur}{iNeuron}==uniqueApparent(iApparent)));
            end
            meanStepRperApparent(iND,iStepDur,iApparent)=nanmean(meanPerNeuron);
            semStepRperApparent(iND,iStepDur,iApparent)=nanstd(meanPerNeuron)./sqrt(length(meanPerNeuron));
        end
    end
end

%for peak Responses
meanPeakRperWeber=zeros(length(ndNums),length(stepDurs),length(uniqueWeber));
meanPeakRperApparent=zeros(length(ndNums),length(stepDurs),length(uniqueApparent));
semPeakRperWeber=zeros(length(ndNums),length(stepDurs),length(uniqueWeber));
semPeakRperApparent=zeros(length(ndNums),length(stepDurs),length(uniqueApparent));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % extract for Weber contrasts
        for iWeber=1:length(uniqueWeber)
            meanPerNeuron=zeros(length(weberConts{iND,iStepDur}),1);
            for iNeuron=1:length(weberConts{iND,iStepDur})
                meanPerNeuron(iNeuron)=nanmean(peakResponses{iND,iStepDur}{iNeuron}...
                    (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber)));
            end
            meanPeakRperWeber(iND,iStepDur,iWeber)=nanmean(meanPerNeuron);
            semPeakRperWeber(iND,iStepDur,iWeber)=nanstd(meanPerNeuron)./sqrt(length(meanPerNeuron));
        end
        % extract for apparent contrasts
        for iApparent=1:length(uniqueApparent)
            meanPerNeuron=zeros(length(apparentConts{iND,iStepDur}),1);
            for iNeuron=1:length(apparentConts{iND,iStepDur})
                meanPerNeuron(iNeuron)=nanmean(peakResponses{iND,iStepDur}{iNeuron}...
                    (apparentConts{iND,iStepDur}{iNeuron}==uniqueApparent(iApparent)));
            end
            meanPeakRperApparent(iND,iStepDur,iApparent)=nanmean(meanPerNeuron);
            semPeakRperApparent(iND,iStepDur,iApparent)=nanstd(meanPerNeuron)./sqrt(length(meanPerNeuron));
        end
    end
end

%% plot these stats
% do this for negative contrasts alone
negWeber=uniqueWeber(uniqueWeber<0);
negApparent=uniqueApparent(uniqueApparent<0);
% step responses vs Weber contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        errorbar(negWeber,squeeze(meanStepRperWeber(iND,iStepDur,uniqueWeber<0)),...
            squeeze(semStepRperWeber(iND,iStepDur,uniqueWeber<0)))
        xlabel('Weber contrast')
        ylabel('mean L2 step response (dF/F)')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([-1.25 0]);
    end
end

% step response vs apparent contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on     
        errorbar(negApparent,squeeze(meanStepRperApparent(iND,iStepDur,uniqueApparent<0)),...
            squeeze(semStepRperApparent(iND,iStepDur,uniqueApparent<0)));
        xlabel('Apparent contrast')
        ylabel('mean L2 step response (dF/F)')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([-3.5 0])
    end
end

% peak responses vs Weber contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        errorbar(negWeber,squeeze(meanPeakRperWeber(iND,iStepDur,uniqueWeber<0)),...
            squeeze(semPeakRperWeber(iND,iStepDur,uniqueWeber<0)))
        xlabel('Weber contrast')
        ylabel('mean L2 peak response (dF/F)')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([-1.25 0]);
    end
end

% peak response vs apparent contrast
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on     
        errorbar(negApparent,squeeze(meanPeakRperApparent(iND,iStepDur,uniqueApparent<0)),...
            squeeze(semPeakRperApparent(iND,iStepDur,uniqueApparent<0)));
        xlabel('Apparent contrast')
        ylabel('mean L2 peak response (dF/F)')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([-3.5 0])
    end
end
%peak responses seem more correlated with Weber contrast, whereas step
%responses with apparent contrast. This is just eyeballing, however.

%% assess correlation of each neuron with each type of contrasts
% shows better (negative) correlation with apparent contrast, especially at stepDur 0.5
corrCoefsWeber=cell(length(ndNums),length(stepDurs));
corrCoefsApparent=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % calculate for Weber contrasts
        currCell=zeros(length(weberConts{iND,iStepDur}),1);
        for iNeuron=1:length(weberConts{iND,iStepDur})
            %get rid of Inf contrasts
            currConts=weberConts{iND,iStepDur}{iNeuron}(weberConts{iND,iStepDur}{iNeuron}~=Inf);
            currResponses=stepResponses{iND,iStepDur}{iNeuron}(weberConts{iND,iStepDur}{iNeuron}~=Inf);
            currCell(iNeuron)=corr(currConts,currResponses);                
        end
        corrCoefsWeber{iND,iStepDur}=currCell;
        
        % calculate for Apparent contrasts
        currCell=zeros(length(apparentConts{iND,iStepDur}),1);
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            %get rid of Inf contrasts
            currConts=apparentConts{iND,iStepDur}{iNeuron}(apparentConts{iND,iStepDur}{iNeuron}~=Inf);
            currResponses=stepResponses{iND,iStepDur}{iNeuron}(apparentConts{iND,iStepDur}{iNeuron}~=Inf);
            currCell(iNeuron)=corr(currConts,currResponses);                      
        end
        corrCoefsApparent{iND,iStepDur}=currCell;
    end
end

% boxplot
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        boxplot([corrCoefsWeber{iND,iStepDur},corrCoefsApparent{iND,iStepDur}],...
            'Notch','on','Labels',{'Weber','Apparent'})
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        ylim([-1 0])
    end
end

% errorbar
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        errorbar(1,mean(corrCoefsWeber{iND,iStepDur}),std(corrCoefsWeber{iND,iStepDur}),'o')
        errorbar(2,mean(corrCoefsApparent{iND,iStepDur}),std(corrCoefsApparent{iND,iStepDur}),'o')
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        xticks([1,2]); xticklabels({'weber','apparent'})
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([0.5 2.5])
    end
end

% paired plots joining Weber and apparent coefficients for each neuron
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(weberConts{iND,iStepDur})
            line([1,2],[corrCoefsWeber{iND,iStepDur}(iNeuron),corrCoefsApparent{iND,iStepDur}(iNeuron)],'Marker','o')
        end
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        xticks([1,2]); xticklabels({'weber','apparent'})
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([0.5 2.5])
        ylim([-1 0])
    end
end

%% extract individual responses of each neuron to unique contrasts
%first for step responses
%simultaneously save background luminance for each weber
stepRperNeuron_perWeber=cell(length(ndNums),length(stepDurs));
stepRperNeuron_perApparent=cell(length(ndNums),length(stepDurs));
bgLperNeuron_perWeber=cell(length(ndNums),length(stepDurs));
meanStepRperNeuron_perWeber=cell(length(ndNums),length(stepDurs));
meanStepRperNeuron_perApparent=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % extract for Weber contrasts
        currCell=cell(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        currCellLum=cell(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        currMat=zeros(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        for iNeuron=1:length(weberConts{iND,iStepDur})
            for iWeber=1:length(uniqueWeber)
                currCell{iNeuron,iWeber}=stepResponses{iND,iStepDur}{iNeuron}...
                (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber));
                currMat(iNeuron,iWeber)=nanmean(currCell{iNeuron,iWeber});
                
                currCellLum{iNeuron,iWeber}=bgLums{iND,iStepDur}{iNeuron}...
                (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber));
            end 
        end
        stepRperNeuron_perWeber{iND,iStepDur}=currCell;
        meanStepRperNeuron_perWeber{iND,iStepDur}=currMat;
        bgLperNeuron_perWeber{iND,iStepDur}=currCellLum;
        
        % extract for Apparent contrasts
        currCell=cell(length(apparentConts{iND,iStepDur}),length(uniqueApparent));
        currMat=zeros(length(apparentConts{iND,iStepDur}),length(uniqueApparent));
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            for iApparent=1:length(uniqueApparent)
                currCell{iNeuron,iApparent}=stepResponses{iND,iStepDur}{iNeuron}...
                (apparentConts{iND,iStepDur}{iNeuron}==uniqueApparent(iApparent));
                currMat(iNeuron,iApparent)=nanmean(currCell{iNeuron,iApparent});
            end                      
        end
        stepRperNeuron_perApparent{iND,iStepDur}=currCell;
        meanStepRperNeuron_perApparent{iND,iStepDur}=currMat;
    end
end

% one could compare response variance across individual Weber and Apparent,
% but the number of observations per contrast is not comparable.
% As a second thought, compare correlations with mean responses to each contrast
corrCoefsWeber2=cell(length(ndNums),length(stepDurs));
corrCoefsApparent2=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % calculate for Weber contrasts
        currCell=zeros(length(weberConts{iND,iStepDur}),1);
        for iNeuron=1:length(weberConts{iND,iStepDur})
            %avoid -Inf by rejecting the last Weber
            %also, get rid of nan
            currConts=uniqueWeber(1:end-1);
            currResponses=meanStepRperNeuron_perWeber{iND,iStepDur}(iNeuron,1:end-1);
            currCell(iNeuron)=corr(currConts(~isnan(currResponses)),currResponses(~isnan(currResponses))');                
        end
        corrCoefsWeber2{iND,iStepDur}=currCell;
        
        % calculate for Apparent contrasts
        currCell=zeros(length(apparentConts{iND,iStepDur}),1);
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            currResponses=meanStepRperNeuron_perApparent{iND,iStepDur}(iNeuron,:);
            currCell(iNeuron)=corr(uniqueApparent(~isnan(currResponses)),currResponses(~isnan(currResponses))');                      
        end
        corrCoefsApparent2{iND,iStepDur}=currCell;
    end
end

% boxplot 
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        boxplot([corrCoefsWeber2{iND,iStepDur},corrCoefsApparent2{iND,iStepDur}],...
            'Notch','on','Labels',{'Weber','Apparent'})
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        ylim([-1 -0.5])
        set(gca,'tickdir','out')
        box off
    end
end

% plot paired values
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(weberConts{iND,iStepDur})
            line([1,2],[corrCoefsWeber2{iND,iStepDur}(iNeuron),corrCoefsApparent2{iND,iStepDur}(iNeuron)],'Marker','o')
        end
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        xticks([1,2]); xticklabels({'weber','apparent'})
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([0.5 2.5])
        ylim([-1 0])
        set(gca,'tickdir','out')
        box off
    end
end

%% same for peak responses
peakRperNeuron_perWeber=cell(length(ndNums),length(stepDurs));
peakRperNeuron_perApparent=cell(length(ndNums),length(stepDurs));
meanPeakRperNeuron_perWeber=cell(length(ndNums),length(stepDurs));
meanPeakRperNeuron_perApparent=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % extract for Weber contrasts
        currCell=cell(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        currCellLum=cell(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        currMat=zeros(length(weberConts{iND,iStepDur}),length(uniqueWeber));
        for iNeuron=1:length(weberConts{iND,iStepDur})
            for iWeber=1:length(uniqueWeber)
                currCell{iNeuron,iWeber}=peakResponses{iND,iStepDur}{iNeuron}...
                (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber));
                currMat(iNeuron,iWeber)=nanmean(currCell{iNeuron,iWeber});
                
                currCellLum{iNeuron,iWeber}=bgLums{iND,iStepDur}{iNeuron}...
                (weberConts{iND,iStepDur}{iNeuron}==uniqueWeber(iWeber));
            end 
        end
        peakRperNeuron_perWeber{iND,iStepDur}=currCell;
        meanPeakRperNeuron_perWeber{iND,iStepDur}=currMat;
        bgLperNeuron_perWeber{iND,iStepDur}=currCellLum;
        
        % extract for Apparent contrasts
        currCell=cell(length(apparentConts{iND,iStepDur}),length(uniqueApparent));
        currMat=zeros(length(apparentConts{iND,iStepDur}),length(uniqueApparent));
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            for iApparent=1:length(uniqueApparent)
                currCell{iNeuron,iApparent}=peakResponses{iND,iStepDur}{iNeuron}...
                (apparentConts{iND,iStepDur}{iNeuron}==uniqueApparent(iApparent));
                currMat(iNeuron,iApparent)=nanmean(currCell{iNeuron,iApparent});
            end                      
        end
        peakRperNeuron_perApparent{iND,iStepDur}=currCell;
        meanPeakRperNeuron_perApparent{iND,iStepDur}=currMat;
    end
end

% calculate correlation
corrCoefsWeber3=cell(length(ndNums),length(stepDurs));
corrCoefsApparent3=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        % calculate for Weber contrasts
        currCell=zeros(length(weberConts{iND,iStepDur}),1);
        for iNeuron=1:length(weberConts{iND,iStepDur})
            %avoid -Inf by rejecting the last Weber
            %also, get rid of nan
            currConts=uniqueWeber(1:end-1);
            currResponses=meanPeakRperNeuron_perWeber{iND,iStepDur}(iNeuron,1:end-1);
            currCell(iNeuron)=corr(currConts(~isnan(currResponses)),currResponses(~isnan(currResponses))');                
        end
        corrCoefsWeber3{iND,iStepDur}=currCell;
        
        % calculate for Apparent contrasts
        currCell=zeros(length(apparentConts{iND,iStepDur}),1);
        for iNeuron=1:length(apparentConts{iND,iStepDur})
            currResponses=meanPeakRperNeuron_perApparent{iND,iStepDur}(iNeuron,:);
            currCell(iNeuron)=corr(uniqueApparent(~isnan(currResponses)),currResponses(~isnan(currResponses))');                      
        end
        corrCoefsApparent3{iND,iStepDur}=currCell;
    end
end

figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        boxplot([corrCoefsWeber3{iND,iStepDur},corrCoefsApparent3{iND,iStepDur}],...
            'Notch','on','Labels',{'Weber','Apparent'})
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        ylim([-1 -0])
        set(gca,'tickdir','out')
        box off
    end
end

% plot paired values
figure; counter=0;
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        counter=counter+1;
        subplot(length(ndNums),length(stepDurs),counter); hold on
        for iNeuron=1:length(weberConts{iND,iStepDur})
            line([1,2],[corrCoefsWeber3{iND,iStepDur}(iNeuron),corrCoefsApparent3{iND,iStepDur}(iNeuron)],'Marker','o')
        end
        xlabel('contrast definition')
        ylabel('correlation coefficient')
        xticks([1,2]); xticklabels({'weber','apparent'})
        title([ndNames{iND},', ',stepDurNames{iStepDur},'s step duration'])
        xlim([0.5 2.5])
        ylim([-1 0])
    end
end

%% Analyse if variance of response to same weber contrast is different across timescales
% for -1 weber contrast that has 5-8 instances
% average the same instance across neurons
StepR_perInstance=cell(length(ndNums),length(stepDurs));
meanStepR_perInstance=cell(length(ndNums),length(stepDurs));
stdStepR_perInstance=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        instances=zeros(size(stepRperNeuron_perWeber{iND, iStepDur},1),...
            length(stepRperNeuron_perWeber{iND, iStepDur}{1,1}));
        for iNeuron=1:size(stepRperNeuron_perWeber{iND, iStepDur},1)
            instances(iNeuron,:)=stepRperNeuron_perWeber{iND, iStepDur}{iNeuron,1};
        end
        StepR_perInstance{iND,iStepDur}=instances;
        meanStepR_perInstance{iND,iStepDur}=nanmean(instances);
        stdStepR_perInstance{iND,iStepDur}=nanstd(instances);
    end
end

% anova1 shows that responses at different instances are significantly
% different at all four timescales.

%% Same for an apparent contrast, -0.6
StepR_perInstance=cell(length(ndNums),length(stepDurs));
meanStepR_perInstance=cell(length(ndNums),length(stepDurs));
stdStepR_perInstance=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        instances=zeros(size(stepRperNeuron_perApparent{iND, iStepDur},1),...
            length(stepRperNeuron_perApparent{iND, iStepDur}{1,9}));
        for iNeuron=1:size(stepRperNeuron_perApparent{iND, iStepDur},1)
            instances(iNeuron,:)=stepRperNeuron_perApparent{iND, iStepDur}{iNeuron,9};
        end
        StepR_perInstance{iND,iStepDur}=instances;
        meanStepR_perInstance{iND,iStepDur}=nanmean(instances);
        stdStepR_perInstance{iND,iStepDur}=nanstd(instances);
    end
end

% anova1 shows the same for this too.. cannot claim just for weber contrast then.

%% plot responses to -1 weber contrast against background lum
% for step responses
uniqueLums=unique(bgLperNeuron_perWeber{1,1}{1,1});%unique bgLum values
StepR100_perLum=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        currR=zeros(size(stepRperNeuron_perWeber{iND, iStepDur},1),length(uniqueLums));
        for iNeuron=1:size(stepRperNeuron_perWeber{iND, iStepDur},1)
            for iLum=1:length(uniqueLums)
                currR(iNeuron,iLum)=nanmean(stepRperNeuron_perWeber{iND, iStepDur}{iNeuron,1}...
                    (bgLperNeuron_perWeber{iND, iStepDur}{iNeuron,1}==uniqueLums(iLum)));
            end
        end
        StepR100_perLum{iND,iStepDur}=currR;
    end
end
%plot
figure;counter=0;
for iND=1:length(ndNums)
    counter=counter+1;
    subplot(1,2,counter); hold on % 2subplots for 2 NDs
    for iStepDur=1:length(stepDurs)
        errorbar(uniqueLums,nanmean(StepR100_perLum{iND,iStepDur}),...
            nanstd(StepR100_perLum{iND,iStepDur})/sqrt(size(StepR100_perLum{iND,iStepDur},1)),'-o')
    end
    legend(stepDurNames,'location','best')
    xlabel('Background luminance (LED)')
    ylabel('L2 response (normalized dF/F)')
    title(ndNames{iND})
    xlim([0.7 20])
    set(gca,'xscale','log')
end

% for peak responses
uniqueLums=unique(bgLperNeuron_perWeber{1,1}{1,1});%unique bgLum values
PeakR100_perLum=cell(length(ndNums),length(stepDurs));
for iND=1:length(ndNums)
    for iStepDur=1:length(stepDurs)
        currR=zeros(size(peakRperNeuron_perWeber{iND, iStepDur},1),length(uniqueLums));
        for iNeuron=1:size(peakRperNeuron_perWeber{iND, iStepDur},1)
            for iLum=1:length(uniqueLums)
                currR(iNeuron,iLum)=nanmean(peakRperNeuron_perWeber{iND, iStepDur}{iNeuron,1}...
                    (bgLperNeuron_perWeber{iND, iStepDur}{iNeuron,1}==uniqueLums(iLum)));
            end
        end
        PeakR100_perLum{iND,iStepDur}=currR;
    end
end
%plot
figure;counter=0;
for iND=1:length(ndNums)
    counter=counter+1;
    subplot(1,2,counter); hold on % 2subplots for 2 NDs
    for iStepDur=1:length(stepDurs)
        errorbar(uniqueLums,nanmean(PeakR100_perLum{iND,iStepDur}),...
            nanstd(PeakR100_perLum{iND,iStepDur})/sqrt(size(PeakR100_perLum{iND,iStepDur},1)),'-o')
    end
    legend(stepDurNames,'location','best')
    xlabel('Background luminance (LED)')
    ylabel('L2 response (normalized dF/F)')
    title(ndNames{iND})
    xlim([0.7 20])
    set(gca,'xscale','log')
end