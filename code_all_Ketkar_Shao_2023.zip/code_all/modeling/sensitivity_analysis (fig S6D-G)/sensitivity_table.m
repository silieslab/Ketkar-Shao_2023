all_sensitivity = zeros(7, 14);

all_sensitivity(:, 1) = sensitivity_ue_100;
all_sensitivity(:, 2) = sensitivity_ue_80;
all_sensitivity(:, 3) = sensitivity_ue_50;
all_sensitivity(:, 4) = sensitivity_ue_mixed;
all_sensitivity(:, 5) = mean(all_sensitivity(:, 1:4), 2);

all_sensitivity(:, 6) = sensitivity_oe_80;
all_sensitivity(:, 7) = sensitivity_oe_50;
all_sensitivity(:, 8) = sensitivity_oe_mixed;
all_sensitivity(:, 9) = mean(all_sensitivity(:, 6:8), 2);

all_sensitivity(:, 10) = sensitivity_di_100;
all_sensitivity(:, 11) = sensitivity_di_80;
all_sensitivity(:, 12) = sensitivity_di_50;
all_sensitivity(:, 13) = sensitivity_di_mixed;
all_sensitivity(:, 14) = mean(all_sensitivity(:, 10:13), 2);