load('../train_on_uniform/bootstrap_uniform.mat')

coeff_all = zeros(7, length(mdl_info));
k0_all = zeros(length(mdl_info), 1);

for i = 1:length(mdl_info)
        k0_all(i) = mdl_info{i}.k0;
        coeff_all(:, i) = mdl_info{i}.coeff(:, 1); %a0, a1, a2, a3, a3b0 (-), a4, a5 (-)
end

coeff_mean = mean(coeff_all, 2);
coeff_mean([5, 7]) = - coeff_mean([5, 7]);

k0_avg = mean(k0_all);

compute_terms;

components.L2_response_1 = L2_response_1;
components.L2_response_2 = L2_response_2;
components.L2_response_3 = L2_response_3;
components.L2_response_4 = L2_response_4;
components.L2_response_5 = L2_response_5;
components.L2_response_6 = L2_response_6;
components.filter_high_100 = filter_high_100;
components.filter_high_80 = filter_high_80;
components.filter_high_50 = filter_high_50;
components.L3_response_high_100 = L3_response_high_100;
components.L3_response_high_80 = L3_response_high_80;
components.L3_response_high_50 = L3_response_high_50;
components.L3_response_low_100 = L3_response_low_100;
components.L3_response_low_80 = L3_response_low_80;
components.L3_response_low_50 = L3_response_low_50;
components.lum_edge_1 = lum_edge_1;
components.lum_edge_3 = lum_edge_3;
components.lum_edge_5 = lum_edge_5;
components.int_turn_1 = int_turn_1;
components.int_turn_2 = int_turn_2;
components.int_turn_3 = int_turn_3;
components.int_turn_4 = int_turn_4;
components.int_turn_5 = int_turn_5;
components.int_turn_6 = int_turn_6;
components.real_response_all = real_response_all;
components.int_turn_mixed_1 = int_turn_mixed_1;
components.int_turn_mixed_2 = int_turn_mixed_2;
components.L2_response_mixed = L2_response_mixed;
components.filter_high_mixed = filter_high_mixed;
components.L3_response_high_mixed = L3_response_high_mixed;
components.L3_response_low_mixed = L3_response_low_mixed;
components.lum_edge_mixed = lum_edge_mixed;

coeff_ue = coeff_mean;
coeff_oe = coeff_mean;
coeff_di = coeff_mean;
coeff_ue(4) = 1.1*coeff_ue(4);  %a3 * 1.1
coeff_oe(5) = 1.1*coeff_oe(5);  %a3b0 * 1.1
coeff_oe(7) = 1.1*coeff_oe(7);  %a5 * 1.1
coeff_di(6) = 1.1*coeff_di(6);  %a4 * 1.1

[pred_response_1, pred_response_2, pred_response_3, pred_response_4, pred_response_5, ...
        pred_response_6, pred_response_mixed_1, pred_response_mixed_2] = get_pred(coeff_mean, components);
[pred_response_1_ue, pred_response_2_ue, ~, ~, ~, ~, ~, ~] = get_pred(coeff_ue, components);
[~, ~, pred_response_3_oe, pred_response_4_oe, ~, ~, ~, ~] = get_pred(coeff_oe, components);
[~, ~, ~, ~, ~, ~, pred_response_mixed_1_di, pred_response_mixed_2_di] = get_pred(coeff_di, components);

figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

line_colors_100 = [44, 166, 224; 0, 159, 232; 3, 110, 183; 0, 81, 133; 22, 29, 90]/255;
line_colors_80 = [209, 12, 24; 188, 16, 25; 163, 14, 22; 137, 6, 13; 107, 0, 4]/255;
control_colors = [0.75, 0.75, 0.75; 0.65, 0.65, 0.65; 0.5, 0.5, 0.5; 0.4, 0.4, 0.4; 0, 0, 0];
L2_colors = [71, 175, 55; 44, 171, 58; 17, 153, 60; 16, 128, 57; 13, 103, 50]/255;
mixed_control_colors = [27, 26, 25; 31, 31, 31; 61, 61, 61; 92, 92, 92; 122, 122, 122; 153, 153, 153]/255;
mixed_L2_colors = [13, 103, 50; 24, 118, 51; 35, 133, 52; 46, 148, 53; 57, 163, 54; 68, 178, 58]/255;
mixed_mkr = {'o', 'v', 'p', 's', '^', 'd'};

ax = axes('Position', [0.07, 0.8, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_100(i, :))', pred_response_1(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_100(i, j)), pred_response_1(i, j), 6.96, 'MarkerEdgeColor', control_colors(6-j, :))
        end
        plot(log10(lumValues_100(i, :))', pred_response_2(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_100(i, j)), pred_response_2(i, j), 6.96, 'MarkerEdgeColor', L2_colors(6-j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('Model fit')

ax = axes('Position', [0.57, 0.8, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_100(i, :))', pred_response_1_ue(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_100(i, j)), pred_response_1_ue(i, j), 6.96, 'MarkerEdgeColor', control_colors(6-j, :))
        end
        plot(log10(lumValues_100(i, :))', pred_response_2_ue(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_100(i, j)), pred_response_2_ue(i, j), 6.96, 'MarkerEdgeColor', L2_colors(6-j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('a_3 increased by 10%')

%oe
ax = axes('Position', [0.07, 0.6, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_50(i, :))', pred_response_3(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 6.96, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        end
        plot(log10(lumValues_50(i, :))', pred_response_4(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 6.96, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('Model fit')

ax = axes('Position', [0.57, 0.6, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_50(i, :))', pred_response_3_oe(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_3_oe(i, j), 6.96, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        end
        plot(log10(lumValues_50(i, :))', pred_response_4_oe(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_4_oe(i, j), 6.96, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('a_3b_0 and a_5 increased by 10%')

%di
ax = axes('Position', [0.07, 0.4, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_mixed(i, :))', pred_response_mixed_1(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), pred_response_mixed_1(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_control_colors(j, :))
        end
        plot(log10(lumValues_mixed(i, :))', pred_response_mixed_2(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), pred_response_mixed_2(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_L2_colors(j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('Model fit')

ax = axes('Position', [0.57, 0.4, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_mixed(i, :))', pred_response_mixed_1_di(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), pred_response_mixed_1_di(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_control_colors(j, :))
        end
        plot(log10(lumValues_mixed(i, :))', pred_response_mixed_2_di(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), pred_response_mixed_2_di(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_L2_colors(j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])
title('a_4 increased by 10%')

annotation('textbox', [0.01, 0.97, 0, 0], 'string', '\bfA', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.51, 0.97, 0, 0], 'string', '\bfB', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.01, 0.77, 0, 0], 'string', '\bfC', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.51, 0.77, 0, 0], 'string', '\bfD', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.01, 0.57, 0, 0], 'string', '\bfE', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.51, 0.57, 0, 0], 'string', '\bfF', 'FontSize', 18*0.7, 'FontName', 'Arial')

set(gcf, 'Renderer', 'painters');
savefig('coefficient_effects.fig');
saveas(gcf, 'coefficient_effects.pdf');

function [pred_response_1, pred_response_2, pred_response_3, ...
        pred_response_4, pred_response_5, pred_response_6, ...
        pred_response_mixed_1, pred_response_mixed_2] = get_pred(a, components)

L2_response_1 = components.L2_response_1;
L2_response_2 = components.L2_response_2;
L2_response_3 = components.L2_response_3;
L2_response_4 = components.L2_response_4;
L2_response_5 = components.L2_response_5;
L2_response_6 = components.L2_response_6;
filter_high_100 = components.filter_high_100;
filter_high_80 = components.filter_high_80;
filter_high_50 = components.filter_high_50;
L3_response_high_100 = components.L3_response_high_100;
L3_response_high_80 = components.L3_response_high_80;
L3_response_high_50 = components.L3_response_high_50;
L3_response_low_100 = components.L3_response_low_100;
L3_response_low_80 = components.L3_response_low_80;
L3_response_low_50 = components.L3_response_low_50;
lum_edge_1 = components.lum_edge_1;
lum_edge_3 = components.lum_edge_3;
lum_edge_5 = components.lum_edge_5;
L2_response_mixed = components.L2_response_mixed;
filter_high_mixed = components.filter_high_mixed;
L3_response_high_mixed = components.L3_response_high_mixed;
L3_response_low_mixed = components.L3_response_low_mixed;
lum_edge_mixed = components.lum_edge_mixed;

pred_response_1 = a(1) + a(2) * L2_response_1 + ...
        a(3) + a(4) * filter_high_100 - a(5) * L3_response_high_100 + ...
        a(6) * L3_response_low_100 - a(7) * log10(lum_edge_1) .* tanh(lum_edge_1);

pred_response_3 = a(1) + a(2) * L2_response_3 + ...
        a(3) + a(4) * filter_high_50 - a(5) * L3_response_high_50 + ...
        a(6) * L3_response_low_50 - a(7) * log10(lum_edge_3) .* tanh(lum_edge_3);

pred_response_5 = a(1) + a(2) * L2_response_5 + ...
        a(3) + a(4) * filter_high_80 - a(5) * L3_response_high_80 + ...
        a(6) * L3_response_low_80 - a(7) * log10(lum_edge_5) .* tanh(lum_edge_5);

pred_response_2 = a(1) + a(2) * L2_response_2;
pred_response_4 = a(1) + a(2) * L2_response_4;
pred_response_6 = a(1) + a(2) * L2_response_6;

pred_response_mixed_1 = a(1) + a(2) * L2_response_mixed + ...
        a(3) + a(4) * filter_high_mixed - a(5) * L3_response_high_mixed + ...
        a(6) * L3_response_low_mixed - a(7) * log10(lum_edge_mixed) .* tanh(lum_edge_mixed);

pred_response_mixed_2 = a(1) + a(2) * L2_response_mixed;

end