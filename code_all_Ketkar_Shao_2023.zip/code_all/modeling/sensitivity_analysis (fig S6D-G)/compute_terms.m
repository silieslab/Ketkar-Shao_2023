data = readmatrix('D:\folders\fly_motion_detection\lum_con_integration project\Madhura_codes\contrastResponses.csv');
f = fit(data(:,1), data(:,2), 'a/(1+exp(-b*(x-c)))', 'StartPoint', [100, 1, 5]);

maxL = 1176758.88; %maximal luminance

ND_100 = [1, 8, 64, 512, 4096];
ND_50 = ND_100;
ND_80 = ND_100;

backL_100 = [1, 2, 4, 8, 15];
backL_50 = [2, 4, 6, 8, 10];
backL_80 = [5, 10, 15];

lumValues_100 = (1./ND_100') * backL_100/15 * maxL;
Adaptlum_100 = mean(lumValues_100, 2)*(0.5 + 0.75/2)/(0.5 + 0.75 + 1);

Im = lumValues_100(4, 3);
kI = 10;

cd('../uniform_contrasts_Off_int_turn/100%Off/control_2');
file_1 = dir('*.mat');

levels_100 = size(lumValues_100, 2);
int_turn_1 = zeros(length(file_1), levels_100);
int_turn_1_sem = zeros(length(file_1), levels_100);
contrast_1 = zeros(length(file_1), levels_100);
L2_response_1 = zeros(length(file_1), levels_100);
luminance_1 = lumValues_100;
lum_edge_1 = ones(size(lumValues_100));

for index = 1:length(file_1)
        load(file_1(index).name);
        int_turn_1(index, :) = groupMean;
        int_turn_1_sem(index, :) = groupSEM;
        contrast_1(index, :) = - lumValues_100(index, :)/Adaptlum_100(index);
        k1 = k0_avg*f(log10(Adaptlum_100(index)))/f.a;
        L2_response_1(index, :) = - tanh(contrast_1(index, :)*k1);
end

filter_high_100 = 1./(1+exp(- kI*(log10(luminance_1) - log10(Im))));
L3_response_high_100 = L2_response_1 .* filter_high_100;
L3_response_low_100 = log10(luminance_1) .* (1 - filter_high_100);

cd('../L3_silenced');
file_2 = dir('*.mat');

int_turn_2 = zeros(length(file_2), levels_100);
int_turn_2_sem = zeros(length(file_2), levels_100);
contrast_2 = zeros(length(file_2), levels_100);
L2_response_2 = zeros(length(file_2), levels_100);
luminance_2 = lumValues_100;
lum_edge_2 = ones(size(lumValues_100));

for index = 1:length(file_2)
        load(file_2(index).name);
        int_turn_2(index, :) = groupMean;
        int_turn_2_sem(index, :) = groupSEM;
        contrast_2(index, :) = - lumValues_100(index, :)/Adaptlum_100(index);
        k1 = k0_avg*f(log10(Adaptlum_100(index)))/f.a;
        L2_response_2(index, :) = - tanh(contrast_2(index, :)*k1);
end

%50% contrast
lumValues_50 = (1./ND_50') * backL_50/15 * maxL;
Adaptlum_50 = mean(lumValues_50, 2)*(0.5 + 0.75/2 + 0.75/2*0.5)/(0.5 + 0.75 + 1);

cd('../../50%Off/control_2');
file_3 = dir('*.mat');

levels_50 = size(lumValues_50, 2);
int_turn_3 = zeros(length(file_3), levels_50);
int_turn_3_sem = zeros(length(file_3), levels_50);
contrast_3 = zeros(length(file_3), levels_50);
L2_response_3 = zeros(length(file_3), levels_50);
luminance_3 = lumValues_50;
lum_edge_3 = 0.5*lumValues_50;

for index = 1:length(file_3)
        load(file_3(index).name);
        int_turn_3(index, :) = groupMean;
        int_turn_3_sem(index, :) = groupSEM;
        contrast_3(index, :) = - 0.5*lumValues_50(index, :)/Adaptlum_50(index);
        k1 = k0_avg*f(log10(Adaptlum_50(index)))/f.a;
        L2_response_3(index, :) = - tanh(contrast_3(index, :)*k1);
end

filter_high_50 = 1./(1+exp(- kI*(log10(luminance_3) - log10(Im))));
L3_response_high_50 = L2_response_3 .* filter_high_50;
L3_response_low_50 = log10(luminance_3) .* (1 - filter_high_50);

cd('../L3_silenced');
file_4 = dir('*.mat');

int_turn_4 = zeros(length(file_4), levels_50);
int_turn_4_sem = zeros(length(file_4), levels_50);
contrast_4 = zeros(length(file_4), levels_50);
L2_response_4 = zeros(length(file_4), levels_50);
luminance_4 = lumValues_50;
lum_edge_4 = 0.5*lumValues_50;

for index = 1:length(file_4)
        load(file_4(index).name);
        int_turn_4(index, :) = groupMean;
        int_turn_4_sem(index, :) = groupSEM;
        contrast_4(index, :) = - 0.5*lumValues_50(index, :)/Adaptlum_50(index);
        k1 = k0_avg*f(log10(Adaptlum_50(index)))/f.a;
        L2_response_4(index, :) = - tanh(contrast_4(index, :)*k1);
end

%predict on 80% contrast
lumValues_80 = (1./ND_80') * backL_80/15 * maxL;
Adaptlum_80 = mean(lumValues_80, 2)*(0.5 + 0.75/2 + 0.75/2*0.2)/(0.5 + 0.75 + 1);

cd('../../80%Off/control_2');
file_5 = dir('*.mat');

levels_80 = size(lumValues_80, 2);
int_turn_5 = zeros(length(file_5), levels_80);
int_turn_5_sem = zeros(length(file_5), levels_80);
contrast_5 = zeros(length(file_5), levels_80);
L2_response_5 = zeros(length(file_5), levels_80);
luminance_5 = lumValues_80;
lum_edge_5 = 0.2*lumValues_80;

for index = 1:length(file_5)
        load(file_5(index).name);
        int_turn_5(index, :) = groupMean;
        int_turn_5_sem(index, :) = groupSEM;
        contrast_5(index, :) = - 0.8*lumValues_80(index, :)/Adaptlum_80(index);
        k1 = k0_avg*f(log10(Adaptlum_80(index)))/f.a;
        L2_response_5(index, :) = - tanh(contrast_5(index, :)*k1);
end

filter_high_80 = 1./(1+exp(- kI*(log10(luminance_5) - log10(Im))));
L3_response_high_80 = L2_response_5 .* filter_high_80;
L3_response_low_80 = log10(luminance_5) .* (1 - filter_high_80);

cd('../L3_silenced');
file_6 = dir('*.mat');

int_turn_6 = zeros(length(file_6), levels_80);
int_turn_6_sem = zeros(length(file_6), levels_80);
contrast_6 = zeros(length(file_6), levels_80);
L2_response_6 = zeros(length(file_6), levels_80);
luminance_6 = lumValues_80;
lum_edge_6 = 0.2*lumValues_80;

for index = 1:length(file_6)
        load(file_6(index).name);
        int_turn_6(index, :) = groupMean;
        int_turn_6_sem(index, :) = groupSEM;
        contrast_6(index, :) = - 0.8*lumValues_80(index, :)/Adaptlum_80(index);
        k1 = k0_avg*f(log10(Adaptlum_80(index)))/f.a;
        L2_response_6(index, :) = - tanh(contrast_6(index, :)*k1);
end

real_response_all = [int_turn_1(:); int_turn_2(:); int_turn_3(:); ...
        int_turn_4(:); int_turn_5(:); int_turn_6(:)];

cd('../../../sensitivity_analysis_bootstrap')

ND_mixed = [1, 8, 64, 512, 4096];
backL_mixed = [2, 3, 4, 5, 6, 8];
edgeL_mixed = [1, 1, 1, 1, 1, 1];

ND_num = length(ND_mixed);
levels = length(backL_mixed);

lumValues_mixed = (1./ND_mixed') * backL_mixed/15 * maxL;

file_mixed_1 = dir('../mixed_contrasts_Off_int_turn/UAS*.mat');

int_turn_mixed_1 = zeros(length(file_mixed_1), levels);
int_turn_mixed_1_sem = zeros(length(file_mixed_1), levels);
contrast_mixed = zeros(length(file_mixed_1), levels);
L2_response_mixed = zeros(length(file_mixed_1), levels);
luminance_mixed = lumValues_mixed;
lum_edge_mixed = (1./ND_mixed') * edgeL_mixed/15 * maxL;

Adaptlum_mixed = (mean(lumValues_mixed, 2)*(0.5 + 0.75/2) + mean(lum_edge_mixed, 2)*0.75/2)/(0.5 + 0.75 + 1);

for index = 1:length(file_mixed_1)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_1(index).name]);
        int_turn_mixed_1(index, :) = groupMean;
        int_turn_mixed_1_sem(index, :) = groupSEM;
        contrast_mixed(index, :) = (lum_edge_mixed(index, :) - lumValues_mixed(index, :))/Adaptlum_mixed(index);
        k1 = k0_avg*f(log10(Adaptlum_mixed(index)))/f.a;
        L2_response_mixed(index, :) = - tanh(contrast_mixed(index, :)*k1);
end

file_mixed_2 = dir('../mixed_contrasts_Off_int_turn/L3*.mat');

int_turn_mixed_2 = zeros(length(file_mixed_2), levels);
int_turn_mixed_2_sem = zeros(length(file_mixed_2), levels);

for index = 1:length(file_mixed_2)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_2(index).name]);
        int_turn_mixed_2(index, :) = groupMean;
        int_turn_mixed_2_sem(index, :) = groupSEM;
end

filter_high_mixed = 1./(1+exp(- kI*(log10(luminance_mixed) - log10(Im))));
L3_response_high_mixed = L2_response_mixed .* filter_high_mixed;
L3_response_low_mixed = log10(luminance_mixed) .* (1 - filter_high_mixed);



