load('../train_on_uniform/bootstrap_uniform.mat')

coeff_all = zeros(7, length(mdl_info));
k0_all = zeros(length(mdl_info), 1);

for i = 1:length(mdl_info)
        k0_all(i) = mdl_info{i}.k0;
        coeff_all(:, i) = mdl_info{i}.coeff(:, 1); %a0, a1, a2, a3, a3b0 (-), a4, a5 (-)
end

coeff_mean = mean(coeff_all, 2);
coeff_mean([5, 7]) = - coeff_mean([5, 7]);

k0_avg = mean(k0_all);

compute_terms;

components.L2_response_1 = L2_response_1;
components.L2_response_2 = L2_response_2;
components.L2_response_3 = L2_response_3;
components.L2_response_4 = L2_response_4;
components.L2_response_5 = L2_response_5;
components.L2_response_6 = L2_response_6;
components.filter_high_100 = filter_high_100;
components.filter_high_80 = filter_high_80;
components.filter_high_50 = filter_high_50;
components.L3_response_high_100 = L3_response_high_100;
components.L3_response_high_80 = L3_response_high_80;
components.L3_response_high_50 = L3_response_high_50;
components.L3_response_low_100 = L3_response_low_100;
components.L3_response_low_80 = L3_response_low_80;
components.L3_response_low_50 = L3_response_low_50;
components.lum_edge_1 = lum_edge_1;
components.lum_edge_3 = lum_edge_3;
components.lum_edge_5 = lum_edge_5;
components.int_turn_1 = int_turn_1;
components.int_turn_2 = int_turn_2;
components.int_turn_3 = int_turn_3;
components.int_turn_4 = int_turn_4;
components.int_turn_5 = int_turn_5;
components.int_turn_6 = int_turn_6;
components.real_response_all = real_response_all;
components.int_turn_mixed_1 = int_turn_mixed_1;
components.int_turn_mixed_2 = int_turn_mixed_2;
components.L2_response_mixed = L2_response_mixed;
components.filter_high_mixed = filter_high_mixed;
components.L3_response_high_mixed = L3_response_high_mixed;
components.L3_response_low_mixed = L3_response_low_mixed;
components.lum_edge_mixed = lum_edge_mixed;

oe_80_data = mean(mean(int_turn_6(1:2, :) - int_turn_5(1:2, :)));
oe_50_data = mean(mean(int_turn_4(1:2, :) - int_turn_3(1:2, :)));
oe_mixed_data = mean(mean(int_turn_mixed_2(1:2, :) - int_turn_mixed_1(1:2, :)));

realm = 1;
points = 101;

z_score = linspace(-realm, realm, points);

oe_80 = zeros(length(z_score), length(coeff_mean));
oe_50 = zeros(length(z_score), length(coeff_mean));
oe_mixed = zeros(length(z_score), length(coeff_mean));

for j = 1:length(coeff_mean)
        for i = 1:length(z_score)
                a_i = coeff_mean(j)*(1 + z_score(i)*sign(coeff_mean(j)));
                coefficients = [coeff_mean(1:j-1); a_i; coeff_mean(j+1:end)];
                [oe_80(i, j), oe_50(i, j), oe_mixed(i, j)] = get_overestimation(coefficients, components);
        end
end

sensitivity_oe_80 = zeros(length(coeff_mean), 1);
sensitivity_oe_50 = zeros(length(coeff_mean), 1);
sensitivity_oe_mixed = zeros(length(coeff_mean), 1);

for j = 1:length(coeff_mean)
        fit_oe_80 = fit(z_score', oe_80(:, j), 'a*x+b', 'StartPoint', [0, oe_80_data]);
        sensitivity_oe_80(j) = fit_oe_80.a/oe_80(round((points+1)/2), j);

        fit_oe_50 = fit(z_score', oe_50(:, j), 'a*x+b', 'StartPoint', [0, oe_50_data]);
        sensitivity_oe_50(j) = fit_oe_50.a/oe_50(round((points+1)/2), j);

        fit_oe_mixed = fit(z_score', oe_mixed(:, j), 'a*x+b', 'StartPoint', [0, oe_mixed_data]);
        sensitivity_oe_mixed(j) = fit_oe_mixed.a/oe_mixed(round((points+1)/2), j);
end

if ~isfolder('overestimation')
        mkdir('overestimation')
end

colors{1} = [50, 250, 50]/255;
colors{2} = [0, 128, 0]/255;
colors{3} = [135, 206, 250]/255;
colors{4} = [70, 130, 180]/255;
colors{5} = [0, 0, 139]/255;
colors{6} = [75, 0, 130]/255;
colors{7} = [0, 0, 0];
red_color = [255, 69, 0]/255;

figure
set(gcf, 'color', [1 1 1])
hold on
for j = 1:length(coeff_mean)
        plot(z_score, oe_80(:, j), 'color', colors{j}, 'LineWidth', 2)
end
scatter(0, oe_80_data, 200, 'x', 'MarkerEdgeColor', red_color, 'LineWidth', 2)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',15);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 1)
xlabel('z')
ylabel('Overestimation (80%)')
%legend({'a_0', 'a_1', 'a_2', 'a_3', 'a_3b_0', 'a_4', 'a_5'})
savefig(gcf, 'overestimation/oe_80.fig')
saveas(gcf, 'overestimation/oe_80.pdf')
saveas(gcf, 'overestimation/oe_80.png')

figure
set(gcf, 'color', [1 1 1])
hold on
for j = 1:length(coeff_mean)
        plot(z_score, oe_50(:, j), 'color', colors{j}, 'LineWidth', 2)
end
scatter(0, oe_50_data, 200, 'x', 'MarkerEdgeColor', red_color, 'LineWidth', 2)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',15);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 1)
xlabel('z')
ylabel('Overestimation (50%)')
%legend({'a_0', 'a_1', 'a_2', 'a_3', 'a_3b_0', 'a_4', 'a_5'})
savefig(gcf, 'overestimation/oe_50.fig')
saveas(gcf, 'overestimation/oe_50.pdf')
saveas(gcf, 'overestimation/oe_50.png')

figure
set(gcf, 'color', [1 1 1])
hold on
for j = 1:length(coeff_mean)
        plot(z_score, oe_mixed(:, j), 'color', colors{j}, 'LineWidth', 2)
end
scatter(0, oe_mixed_data, 200, 'x', 'MarkerEdgeColor', red_color, 'LineWidth', 2)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',15);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 1)
xlabel('z')
ylabel('Overestimation (mixed)')
%legend({'a_0', 'a_1', 'a_2', 'a_3', 'a_3b_0', 'a_4', 'a_5'})
savefig(gcf, 'overestimation/oe_mixed.fig')
saveas(gcf, 'overestimation/oe_mixed.pdf')
saveas(gcf, 'overestimation/oe_mixed.png')

table_oe = [sensitivity_oe_80, sensitivity_oe_50, sensitivity_oe_mixed];
table_oe = [table_oe, mean(table_oe, 2)];
        
function [oe_80, oe_50, oe_mixed] = get_overestimation(a, components)

L2_response_3 = components.L2_response_3;
L2_response_4 = components.L2_response_4;
L2_response_5 = components.L2_response_5;
L2_response_6 = components.L2_response_6;
filter_high_80 = components.filter_high_80;
filter_high_50 = components.filter_high_50;
L3_response_high_80 = components.L3_response_high_80;
L3_response_high_50 = components.L3_response_high_50;
L3_response_low_80 = components.L3_response_low_80;
L3_response_low_50 = components.L3_response_low_50;
lum_edge_3 = components.lum_edge_3;
lum_edge_5 = components.lum_edge_5;
L2_response_mixed = components.L2_response_mixed;
filter_high_mixed = components.filter_high_mixed;
L3_response_high_mixed = components.L3_response_high_mixed;
L3_response_low_mixed = components.L3_response_low_mixed;
lum_edge_mixed = components.lum_edge_mixed;

pred_response_3 = a(1) + a(2) * L2_response_3 + ...
        a(3) + a(4) * filter_high_50 - a(5) * L3_response_high_50 + ...
        a(6) * L3_response_low_50 - a(7) * log10(lum_edge_3) .* tanh(lum_edge_3);

pred_response_5 = a(1) + a(2) * L2_response_5 + ...
        a(3) + a(4) * filter_high_80 - a(5) * L3_response_high_80 + ...
        a(6) * L3_response_low_80 - a(7) * log10(lum_edge_5) .* tanh(lum_edge_5);

pred_response_4 = a(1) + a(2) * L2_response_4;
pred_response_6 = a(1) + a(2) * L2_response_6;

pred_response_mixed_1 = a(1) + a(2) * L2_response_mixed + ...
        a(3) + a(4) * filter_high_mixed - a(5) * L3_response_high_mixed + ...
        a(6) * L3_response_low_mixed - a(7) * log10(lum_edge_mixed) .* tanh(lum_edge_mixed);

pred_response_mixed_2 = a(1) + a(2) * L2_response_mixed;

oe_80 = mean(mean(pred_response_6(1:2, :) - pred_response_5(1:2, :)));
oe_50 = mean(mean(pred_response_4(1:2, :) - pred_response_3(1:2, :)));
oe_mixed = mean(mean(pred_response_mixed_2(1:2, :) - pred_response_mixed_1(1:2, :)));

end



