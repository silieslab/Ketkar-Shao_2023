%run after train_100_contrasts

fig_size = [800, 336];
output_dir = 'figures_dichotomy/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

%%
%100% difference
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_100(plot_index, :))',int_turn_1(plot_index, :)'-int_turn_2(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('100% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '100%_difference.fig'])
saveas(gcf, [output_dir, '100%_difference.pdf'])

%80% difference
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_80(plot_index, :))',int_turn_5(plot_index, :)'-int_turn_6(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('80% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.6:0.2:0.2)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '80%_difference.fig'])
saveas(gcf, [output_dir, '80%_difference.pdf'])

%50% difference
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_50(plot_index, :))',int_turn_3(plot_index, :)'-int_turn_4(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('50% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.8:0.2:0.4)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '50%_difference.fig'])
saveas(gcf, [output_dir, '50%_difference.pdf'])

%%

plot_log_lum = 1:0.01:6.5;
plot_fI = 1./(1+exp(- kI*(plot_log_lum - log10(Im))));

%100% difference plus f(I)
plot_index = 1:5;
plot_index_100 = plot_index;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_100(plot_index, :))',int_turn_1(plot_index, :)'-int_turn_2(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('100% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
set(groot,'defaultAxesColorOrder', 'remove')
yyaxis right
plot(plot_log_lum, plot_fI, 'color', [255,140,0]/255, 'LineWidth', 2)
set(gca, 'YColor', [255,140,0]/255)
ylabel('f(I)')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '100%_difference_plus_fI.fig'])
saveas(gcf, [output_dir, '100%_difference_plus_fI.pdf'])

%80% difference plus f(I)
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_80(plot_index, :))',int_turn_5(plot_index, :)'-int_turn_6(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('80% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.6:0.2:0.2)
set(groot,'defaultAxesColorOrder', 'remove')
yyaxis right
plot(plot_log_lum, plot_fI, 'color', [255,140,0]/255, 'LineWidth', 2)
set(gca, 'YColor', [255,140,0]/255)
ylabel('f(I)')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '80%_difference_plus_fI.fig'])
saveas(gcf, [output_dir, '80%_difference_plus_fI.pdf'])

%50% difference plus f(I)
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_50(plot_index, :))',int_turn_3(plot_index, :)'-int_turn_4(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
title('50% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.8:0.2:0.4)
yyaxis right
plot(plot_log_lum, plot_fI, 'color', [255,140,0]/255, 'LineWidth', 2)
set(gca, 'YColor', [255,140,0]/255)
ylabel('f(I)')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, '50%_difference_plus_fI.fig'])
saveas(gcf, [output_dir, '50%_difference_plus_fI.pdf'])

%%

%All contrasts difference
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_100(plot_index, :))',int_turn_1(plot_index, :)'-int_turn_2(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
hold on
plot_index = 1:5;
ax.ColorOrder=[0.8 0 0;0.7 0 0;0.6 0 0;0.5 0 0;0.4 0 0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_80(plot_index, :))',int_turn_5(plot_index, :)'-int_turn_6(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
plot_index = 1:5;
ax.ColorOrder=[0.6 0.6 0.6;0.45 0.45 0.45;0.3 0.3 0.3;0.15 0.15 0.15;0 0 0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_50(plot_index, :))',int_turn_3(plot_index, :)'-int_turn_4(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
title('100%, 80% & 50% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.8:0.2:0.8)
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
text(1.5, -0.2, '100%', 'FontSize', 15, 'color', [0 0 0.8])
text(1.5, -0.35, '80%', 'FontSize', 15, 'color', [0.8 0 0])
text(1.5, -0.5, '50%', 'FontSize', 15, 'color', [0.6 0.6 0.6])
savefig([output_dir, 'all_contrasts_difference.fig'])
saveas(gcf, [output_dir, 'all_contrasts_difference.pdf'])

%All contrasts difference plus f(I)
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0.8;0 0 0.7;0 0 0.6;0 0 0.5;0.0 0 0.4];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_100(plot_index, :))',int_turn_1(plot_index, :)'-int_turn_2(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Difference of integrated turn (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
hold on
plot_index = 1:5;
ax.ColorOrder=[0.8 0 0;0.7 0 0;0.6 0 0;0.5 0 0;0.4 0 0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_80(plot_index, :))',int_turn_5(plot_index, :)'-int_turn_6(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
plot_index = 1:5;
ax.ColorOrder=[0.6 0.6 0.6;0.45 0.45 0.45;0.3 0.3 0.3;0.15 0.15 0.15;0 0 0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10(lumValues_50(plot_index, :))',int_turn_3(plot_index, :)'-int_turn_4(plot_index, :)','--o','linewidth',1.5,'MarkerSize',3)
title('100%, 80% & 50% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.8:0.2:0.8)
text(1.5, -0.2, '100%', 'FontSize', 15, 'color', [0 0 0.8])
text(1.5, -0.35, '80%', 'FontSize', 15, 'color', [0.8 0 0])
text(1.5, -0.5, '50%', 'FontSize', 15, 'color', [0.6 0.6 0.6])
yyaxis right
plot(plot_log_lum, plot_fI, 'color', [255,140,0]/255, 'LineWidth', 2)
set(gca, 'YColor', [255,140,0]/255)
ylabel('f(I)')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northeast');
set(h, 'FontSize', 13.5)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
savefig([output_dir, 'all_contrasts_difference_plus_fI.fig'])
saveas(gcf, [output_dir, 'all_contrasts_difference_plus_fI.pdf'])

set(groot,'defaultAxesColorOrder', 'remove')

