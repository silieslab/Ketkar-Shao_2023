output_dir = 'figures_edge_inh/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

edge_inh_50 = pred_diff_50 - (int_turn_3 - int_turn_4);
edge_inh_80 = pred_diff_80 - (int_turn_5 - int_turn_6);

figure
set(gcf, 'color', [1 1 1])
scatter(log10(lum_edge_3(:)), edge_inh_50(:), 'filled', 'r');
hold on
scatter(log10(lum_edge_5(:)), edge_inh_80(:), 'filled', 'MarkerFaceColor', 0.7*[1 1 1]);
[f_edge_inh, gof] = fit([log10(lum_edge_3(:)); log10(lum_edge_5(:))], [edge_inh_50(:); edge_inh_80(:)], 'a*x', 'StartPoint', 0.1);
R2_edge_term = gof.rsquare;
plot(1:6, f_edge_inh(1:6), 'k', 'LineWidth', 1)
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
legend('50% contrast', '80% contrast', 'a*log_{10}I_{edge}', 'Location', 'northwest')
xlabel('Moving edge luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Discrepancy of L3 contribution (rad)')
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
savefig([output_dir, 'edge_inhibition_term.fig'])
saveas(gcf, [output_dir, 'edge_inhibition_term.pdf'])

