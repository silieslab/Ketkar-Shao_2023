output_dir = 'figures_L2_model/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

x_adapt_lum = 2:0.01:8;

figure;
set(gcf, 'color', [1 1 1])
scatter(data(:, 1), data(:, 2), 'filled')
hold on
plot(x_adapt_lum, f(x_adapt_lum), 'LineWidth', 1);
legend('Data', 'Fitting', 'Location', 'northwest')
xticks(2:8)
xticklabels({'10^2', '10^3', '10^4', '10^5', '10^6', '10^7', '10^8'})
xlabel('Adapting luminance')
ylabel('Response per unit contrast')
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 15);
set(gca, 'Box', 'off')
savefig(gcf, [output_dir, 'L2_gain_lum.fig']);
saveas(gcf, [output_dir, 'L2_gain_lum.pdf']);

log_I = log10(5.5) + [2, 3, 4, 5];
x_values = (-1:0.01:2);

figure;
set(gcf, 'color', [1 1 1]);
for i = 1:length(log_I)
        k1 = k0*f(log_I(i))/f.a;
        plot(x_values, - 50*tanh(x_values*k1), 'LineWidth', 1.5)
        hold on
end
xlabel('Contrast (%)');
ylabel('L2 responses (normalized)')
legend('I = 5.5x10^2', 'I = 5.5x10^3', 'I = 5.5x10^4', 'I = 5.5x10^5')
yticks(-50:25:50)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 15);
savefig(gcf, [output_dir, 'L2_response_contrast.fig']);
saveas(gcf, [output_dir, 'L2_response_contrast.pdf']);




