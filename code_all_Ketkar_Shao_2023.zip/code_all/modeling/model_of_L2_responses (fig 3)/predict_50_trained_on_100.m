pred_response_4_mdl1 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_4;

ND_index = 2;
ND_value = 0.9;

output_dir = 'figures_pred_on_50/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

line_colors_100 = [44, 166, 224; 0, 159, 232; 3, 110, 183; 0, 81, 133; 22, 29, 90]/255;
line_colors_80 = [209, 12, 24; 188, 16, 25; 163, 14, 22; 137, 6, 13; 107, 0, 4]/255;
control_colors = [0.75, 0.75, 0.75; 0.65, 0.65, 0.65; 0.5, 0.5, 0.5; 0.4, 0.4, 0.4; 0, 0, 0];
L2_colors = [71, 175, 55; 44, 171, 58; 17, 153, 60; 16, 128, 57; 13, 103, 50]/255;
mixed_control_colors = [27, 26, 25; 31, 31, 31; 61, 61, 61; 92, 92, 92; 122, 122, 122; 153, 153, 153]/255;
mixed_L2_colors = [13, 103, 50; 24, 118, 51; 35, 133, 52; 46, 148, 53; 57, 163, 54; 68, 178, 58]/255;
mixed_mkr = {'o', 'v', 'p', 's', '^', 'd'};

%50%, all NDs, empirical L2
ax = axes('Position', [0.07, 0.8, 0.4, 0.128]);
hold on
for i = 1:5
        plot(log10(lumValues_50(i, :)), int_turn_3(i, :), 'LineWidth', 0.75, 'color', control_colors(i, :))
        plot(log10(lumValues_50(i, :)), pred_response_4_mdl1(i, :), 'LineWidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                errorbar(log10(lumValues_50(i, j)), int_turn_3(i, j), int_turn_3_sem(i, j), 'linewidth', 0.75, ...
                        'color', control_colors(6-j, :), 'CapSize', 2.2)
                scatter(log10(lumValues_50(i, j)), int_turn_3(i, j), 6.96, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
                scatter(log10(lumValues_50(i, j)), pred_response_4_mdl1(i, j), 6.96, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
        end
end
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
xlim([1.0 6])
ylim([-0.2 0.8])
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Total turning (rad)')
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')

ax = axes('Position', [0.07, 0.6, 0.213, 0.128]);
scatter(int_turn_4(:), pred_response_4_mdl1(:), 6.96, 'filled', 'MarkerFaceColor', L2_colors(3, :))
hold on
plot([-0.1, 0.8], [-0.1, 0.8], 'k--', 'LineWidth', 1)
xlabel('Observed L3-silenced behavior (rad)');
ylabel('Predicted L3-silenced behavior (rad)');
xlim([-0.1, 0.8])
ylim([-0.1, 0.8])
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
SS_tot_all = sum((int_turn_4(:) - mean(int_turn_4(:))).^2);
SS_res_all = sum((int_turn_4(:) - pred_response_4_mdl1(:)).^2);
R_sq_md1 = 1-SS_res_all/SS_tot_all;
text(-0.05, 0.7, ['R^2 = ', num2str(round(R_sq_md1, 3))], 'FontSize', 8*0.7)

savefig(gcf, [output_dir, '50%contrast_two_hypotheses.fig'])
saveas(gcf, [output_dir, '50%contrast_two_hypotheses.pdf'])
