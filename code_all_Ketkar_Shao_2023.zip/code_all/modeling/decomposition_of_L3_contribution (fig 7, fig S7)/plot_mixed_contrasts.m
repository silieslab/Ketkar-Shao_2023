%for bernstein abstract

fig_size = [800, 336];
output_dir = 'figures_L3_correction/';

set(groot,'defaultAxesColorOrder', 'remove')

if ~isfolder(output_dir)
        mkdir(output_dir)
end

figure('Position',[400, 300, fig_size]); ax=gca;
default_color_order = ax.ColorOrder;
ax.ColorOrder= flipud([0 0 0;105 105 105;128 128 128;169 169 169;192 192 192]/255);
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
hold on
for i = 1:ND_num
        plot(log10_lum_mixed{i}, pred_response_1_lum_mixed{i}, '--','linewidth',1.5)
end
plot(log10(lumValues_mixed)', pred_response_mixed_1', 'o','linewidth',1.5,'MarkerSize',5)
ax.ColorOrder=[0 0.8 0;0 0.7 0;0 0.6 0;0 0.5 0;0.0 0.4 0.0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
for i = 1:ND_num
        plot(log10_lum_mixed{i}, pred_response_2_lum_mixed{i}, '--','linewidth',1.5)
end
plot(log10(lumValues_mixed)', pred_response_mixed_2', 'o','linewidth',1.5,'MarkerSize',5)
for i = 1:ND_num
        plot(log10_lum_mixed{i}, pred_response_1b_lum_mixed{i}, 'color', default_color_order(1, :), 'linewidth', 1)
        plot(log10_lum_mixed{i}, pred_response_2b_lum_mixed{i}, 'color', default_color_order(2, :), 'linewidth', 1)
        plot(log10(Adaptlum_mixed(i)), pred_response_1b_mixed{i}, 'o', 'color', default_color_order(1, :), 'linewidth', 1)
        plot(log10(Adaptlum_mixed(i)), pred_response_2b_mixed{i}, 'o', 'color', default_color_order(2, :), 'linewidth', 1)
end
quiver(log10_lum_mixed{2}(end), pred_response_mixed_2(2, end), 0, ...
        correction_L2_mixed{2}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'r')
quiver(log10_lum_mixed{2}(end), pred_response_mixed_2(2, end)+correction_L2_mixed{2}(end), 0, ...
        correction_L3_mixed{2}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'k')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northwest');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Predicted responses (rad)')
text(2.6, 0.8, 'Control', 'FontSize', 13.5, 'color', 'k')
text(2.6, 0.7, 'L3 silenced', 'FontSize', 13.5, 'color', [0 0.8 0])
title('Mixed Contrasts (Model)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
ylim([-0.2 1.0])
savefig([output_dir, 'mixed_contrasts_model.fig'])
saveas(gcf, [output_dir, 'mixed_contrasts_model.pdf'])

set(groot,'defaultAxesColorOrder', 'remove')

