%for bernstein abstract

fig_size = [800, 336];
output_dir = 'figures_L3_correction/';

set(groot,'defaultAxesColorOrder', 'remove')

if ~isfolder(output_dir)
        mkdir(output_dir)
end

%50% prediction
plot_index = 1:5;
figure('Position', [400, 300, fig_size]); ax=gca;
default_color_order = ax.ColorOrder;
ax.ColorOrder = [0 0 0;105 105 105;128 128 128;169 169 169;192 192 192]/255;
set(groot, 'defaultAxesColorOrder', flipud(ax.ColorOrder))
plot(log10_lum_ND_50(plot_index, :)', pred_response_3_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
hold on
plot(log10(lumValues_50(plot_index, :))', pred_response_3(plot_index, :)', 'o', 'linewidth', 1.5, 'MarkerSize', 5)
ax.ColorOrder = [0 0.8 0;0 0.7 0;0 0.6 0;0 0.5 0;0.0 0.4 0.0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10_lum_ND_50(plot_index, :)', pred_response_4_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
plot(log10(lumValues_50(plot_index, :))',pred_response_4(plot_index, :)', 'o','linewidth',1.5,'MarkerSize', 5)
plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
plot(log10(Adaptlum_50(plot_index))', pred_response_3b(plot_index), 'o', 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10(Adaptlum_50(plot_index))', pred_response_4b(plot_index), 'o', 'color', default_color_order(2, :), 'linewidth', 1)
quiver(log10(lumValues_50(1, end)), pred_response_4(1, end), 0, ...
        correction_L2_50_ND{1}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'r')
quiver(log10(lumValues_50(1, end)), pred_response_4(1, end)+correction_L2_50_ND{1}(end), 0, ...
        correction_L3_50_ND{1}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'k')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northwest');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Predicted responses (rad)')
text(2.5, 0.6, 'Control', 'FontSize', 13.5, 'color', 'k')
text(2.5, 0.5, 'L3 silenced', 'FontSize', 13.5, 'color', [0 0.8 0])
title('50% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
ylim([-0.2 1.0])

savefig([output_dir, '50%_model.fig'])
saveas(gcf, [output_dir, '50%_model.pdf'])

%80% prediction
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0;105 105 105;128 128 128;169 169 169;192 192 192]/255;
set(groot,'defaultAxesColorOrder',flipud(ax.ColorOrder))
plot(log10_lum_ND_80(plot_index, :)', pred_response_5_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
hold on
plot(log10(lumValues_80(plot_index, :))', pred_response_5(plot_index, :)','--o','linewidth',1.5,'MarkerSize', 5)
ax.ColorOrder=[0 0.8 0;0 0.7 0;0 0.6 0;0 0.5 0;0.0 0.4 0.0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10_lum_ND_80(plot_index, :)', pred_response_6_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
plot(log10(lumValues_80(plot_index, :))',pred_response_6(plot_index, :)', 'o','linewidth',1.5,'MarkerSize', 5)
plot(log10_lum, pred_response_5b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_6b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
plot(log10(Adaptlum_80(plot_index))', pred_response_5b(plot_index), 'o', 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10(Adaptlum_80(plot_index))', pred_response_6b(plot_index), 'o', 'color', default_color_order(2, :), 'linewidth', 1)
quiver(log10(lumValues_80(1, end)), pred_response_6(1, end), 0, ...
        correction_L2_80_ND{1}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'r')
quiver(log10(lumValues_80(1, end)), pred_response_6(1, end)+correction_L2_80_ND{1}(end), 0, ...
        correction_L3_80_ND{1}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'k')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'northwest');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Predicted responses (rad)')
text(2.6, 0.6, 'Control', 'FontSize', 13.5, 'color', 'k')
text(2.6, 0.5, 'L3 silenced', 'FontSize', 13.5, 'color', [0 0.8 0])
title('80% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
ylim([-0.2 1.0])
savefig([output_dir, '80%_model.fig'])
saveas(gcf, [output_dir, '80%_model.pdf'])

%100% prediction
plot_index = 1:5;
figure('Position',[400, 300, fig_size]); ax=gca;
ax.ColorOrder=[0 0 0;105 105 105;128 128 128;169 169 169;192 192 192]/255;
set(groot,'defaultAxesColorOrder',flipud(ax.ColorOrder))
plot(log10_lum_ND_100(plot_index, :)', pred_response_1_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
hold on
plot(log10(lumValues_100(plot_index, :))', pred_response_1(plot_index, :)', 'o', 'linewidth', 1.5, 'MarkerSize', 5)
ax.ColorOrder=[0 0.8 0;0 0.7 0;0 0.6 0;0 0.5 0;0.0 0.4 0.0];
set(groot,'defaultAxesColorOrder', ax.ColorOrder)
plot(log10_lum_ND_100(plot_index, :)', pred_response_2_ND_lum(plot_index, :)', '--', 'linewidth', 1.5)
plot(log10(lumValues_100(plot_index, :))',pred_response_2(plot_index, :)', 'o','linewidth',1.5,'MarkerSize', 5)
plot(log10_lum, pred_response_1b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_2b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
plot(log10(Adaptlum_100(plot_index))', pred_response_1b(plot_index), 'o', 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10(Adaptlum_100(plot_index))', pred_response_2b(plot_index), 'o', 'color', default_color_order(2, :), 'linewidth', 1)
quiver(log10(lumValues_100(plot_index(4), end)), pred_response_2(plot_index(4), end), 0, ...
        correction_L2_100_ND{plot_index(4)}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'r')
quiver(log10(lumValues_100(plot_index(4), end)) + 0.05, pred_response_2(plot_index(4), end)+...
        correction_L2_100_ND{plot_index(4)}(end), 0, correction_L3_100_ND{plot_index(4)}(end), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', 'k')
h = legend('ND 0', 'ND 0.9', 'ND 1.8', 'ND 2.7', 'ND 3.6', 'Location', 'southeast');
set(h, 'FontSize', 13.5)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
set(gcf, 'color', [1, 1, 1])
ylabel('Predicted responses (rad)')
text(1.2, 0.6, 'Control', 'FontSize', 13.5, 'color', 'k')
text(1.2, 0.5, 'L3 silenced', 'FontSize', 13.5, 'color', [0 0.8 0])
title('100% Weber Contrast')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
ax = gca;
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',13.5);
set(gca, 'Box', 'off')
xlim([1.0 6.5])
ylim([-0.2 1.0])
savefig([output_dir, '100%_model.fig'])
saveas(gcf, [output_dir, '100%_model.pdf'])

set(groot,'defaultAxesColorOrder', 'remove')

