run('L3_decompose.m')
run('L3_decompose_mixed.m')

if ~isfolder('L3_correction_make_figures')
        mkdir('L3_correction_make_figures')
end

figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

line_colors_100 = [44, 166, 224; 0, 159, 232; 3, 110, 183; 0, 81, 133; 22, 29, 90]/255;
line_colors_80 = [209, 12, 24; 188, 16, 25; 163, 14, 22; 137, 6, 13; 107, 0, 4]/255;
control_colors = [0.75, 0.75, 0.75; 0.65, 0.65, 0.65; 0.5, 0.5, 0.5; 0.4, 0.4, 0.4; 0, 0, 0];
L2_colors = [71, 175, 55; 44, 171, 58; 17, 153, 60; 16, 128, 57; 13, 103, 50]/255;
mixed_control_colors = [27, 26, 25; 31, 31, 31; 61, 61, 61; 92, 92, 92; 122, 122, 122; 153, 153, 153]/255;
mixed_L2_colors = [13, 103, 50; 24, 118, 51; 35, 133, 52; 46, 148, 53; 57, 163, 54; 68, 178, 58]/255;
mixed_mkr = {'o', 'v', 'p', 's', '^', 'd'};

%%

%50% fully adapted
ax = axes('Position', [0.1, 0.6, 0.4, 0.12]);
hold on
default_color_order = ax.ColorOrder;
plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 0.5])

%%

%50%
ax = axes('Position', [0.575, 0.8, 0.4, 0.12]);
hold on
default_color_order = ax.ColorOrder;
for i = 1:5
        plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        end
        plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
        for j = 1:5
                scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
        end
end
plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
rectangle('Position', [log10(lumValues_50(1, 1)) - 0.1, 0, log10(lumValues_50(1, end)) - log10(lumValues_50(1, 1)) + 0.2, 0.8])
rectangle('Position', [log10(lumValues_50(4, 1)) - 0.1, -0.05, log10(lumValues_50(4, end)) - log10(lumValues_50(4, 1)) + 0.2, 0.4])
xlim([1.0 6.5])
ylim([-0.2 0.8])

%%
%ND 2.7

i = 4;
y_lim = [-0.050 0.35];
x_ticks = [2, 2+log10(2), 2+log10(5), 3, 3+log10(2), 3+log10(5)];
x_tick_labels = {'10^2', '2x10^2', '5x10^2', '10^3', '2x10^3', '5x10^3'};

ax = axes('Position', [0.58, 0.6, 0.17, 0.11]);
hold on
plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
for j = 1:5
        scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
end
plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
%plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
%plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_3_ND_lum(i, :), flip(pred_response_4_ND_lum(i, :))], ...
        L2_colors(3, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j), 0, ...
                pred_response_3(i, j) - pred_response_4(i, j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', L2_colors(3, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
title('L3 correction')

ax = axes('Position', [0.58, 0.42, 0.17, 0.11]);
default_color_order = ax.ColorOrder;
hold on
%plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
for j = 1:5
        %scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
end
plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
%plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_4_ND_lum(i, :), flip(pred_response_4_ND_lum(i, :) + ...
        correction_L2_50_ND_lum{i})], default_color_order(2, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j), 0, ...
                correction_L2_50_ND{i}(j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', default_color_order(2, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
%xlabel('Background luminance (photons s^{-1} receptor^{-1})')
title('Correction on L2')
ylabel('Predicted responses (rad)')

ax = axes('Position', [0.58, 0.24, 0.17, 0.11]);
default_color_order = ax.ColorOrder;
hold on
%plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
%plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
%for j = 1:5
    %    scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
    %    scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
%end
plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_4_ND_lum(i, :)+correction_L2_50_ND_lum{i}, ...
        flip(pred_response_4_ND_lum(i, :)+correction_L2_50_ND_lum{i})] + ...
        [zeros(1, 100), flip(correction_L3_50_ND_lum_2{i})], default_color_order(1, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j)+correction_L2_50_ND{i}(j), 0, ...
                correction_L3_50_ND_2{i}(j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', default_color_order(1, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
title('Luminance-only correction')

%%
%ND 0

i = 1;
y_lim = [0 0.8];
x_ticks = [5, 5+log10(2), 5+log10(5), 6];
x_tick_labels = {'10^5', '2x10^5', '5x10^5', '10^6'};

%100%
ax = axes('Position', [0.8, 0.6, 0.17, 0.11]);
hold on
plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
for j = 1:5
        scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
end
%plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
%plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_3_ND_lum(i, :), flip(pred_response_4_ND_lum(i, :))], ...
        L2_colors(3, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j), 0, ...
                pred_response_3(i, j) - pred_response_4(i, j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', L2_colors(3, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
%ylabel({'Predicted / fitted', 'responses (rad)'})
%title('L3 correction')

ax = axes('Position', [0.8, 0.42, 0.17, 0.11]);
default_color_order = ax.ColorOrder;
hold on
%plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
for j = 1:5
        %scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
end
%plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_4_ND_lum(i, :), flip(pred_response_4_ND_lum(i, :) + ...
        correction_L2_50_ND_lum{i})], default_color_order(2, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j), 0, ...
                correction_L2_50_ND{i}(j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', default_color_order(2, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
%title('Correction on L2')

ax = axes('Position', [0.8, 0.24, 0.17, 0.11]);
default_color_order = ax.ColorOrder;
hold on
%plot(log10_lum_ND_50(i, :), pred_response_3_ND_lum(i, :), 'linewidth', 1, 'color', control_colors(i, :))
%plot(log10(lumValues_50(i, :))', pred_response_3(i, :)','o','linewidth',1,'MarkerSize', 5, 'color', control_colors(i, :))
%plot(log10_lum_ND_50(i, :), pred_response_4_ND_lum(i, :), 'linewidth', 1, 'color', L2_colors(i, :))
%plot(log10(lumValues_50(i, :))',pred_response_4(i, :)', 'o','linewidth',1,'MarkerSize', 5, 'color', L2_colors(i, :))
%for j = 1:5
    %    scatter(log10(lumValues_50(i, j)), pred_response_3(i, j), 26*0.7, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
    %    scatter(log10(lumValues_50(i, j)), pred_response_4(i, j), 26*0.7, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
%end
plot(log10_lum, pred_response_3b_lum, 'color', default_color_order(1, :), 'linewidth', 1)
plot(log10_lum, pred_response_4b_lum, 'color', default_color_order(2, :), 'linewidth', 1)
fill([log10_lum_ND_50(i, :), flip(log10_lum_ND_50(i, :))], [pred_response_4_ND_lum(i, :)+correction_L2_50_ND_lum{i}, ...
        flip(pred_response_4_ND_lum(i, :)+correction_L2_50_ND_lum{i})] + ...
        [zeros(1, 100), flip(correction_L3_50_ND_lum_2{i})], default_color_order(1, :), 'LineStyle', 'none', 'FaceAlpha', 0.3)
for j = 1:5
        quiver(log10(lumValues_50(i, j)), pred_response_4(i, j)+correction_L2_50_ND{i}(j), 0, ...
                correction_L3_50_ND_2{i}(j), 0, 'MaxHeadSize', 1, 'LineWidth', 2, 'color', default_color_order(1, :))
end
xticks(x_ticks)
xticklabels(x_tick_labels)
%yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize',10*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([log10(lumValues_50(i, 1)) - 0.1, log10(lumValues_50(i, end)) + 0.1])
ylim(y_lim)
%title('Luminance-only correction')

annotation('textbox', [0.01, 0.96, 0, 0], 'string', '\bfA', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.01, 0.75, 0, 0], 'string', '\bfB', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.47, 0.96, 0, 0], 'string', '\bfC', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.5, 0.75, 0, 0], 'string', '\bfD', 'FontSize', 18*0.7, 'FontName', 'Arial')
annotation('textbox', [0.01, 0.54, 0, 0], 'string', '\bfE', 'FontSize', 18*0.7, 'FontName', 'Arial')

savefig(gcf, 'L3_correction_make_figures/L3_decomposition_main.fig')
saveas(gcf, 'L3_correction_make_figures/L3_decomposition_main.pdf')


