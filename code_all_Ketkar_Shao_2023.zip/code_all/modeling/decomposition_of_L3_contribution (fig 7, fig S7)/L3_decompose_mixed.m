maxL = 1176758.88; %maximal luminance

ND_mixed = [1, 8, 64, 512, 4096];
backL_mixed = [2, 3, 4, 5, 6, 8];
edgeL_mixed = [1, 1, 1, 1, 1, 1];

ND_num = length(ND_mixed);
levels = length(backL_mixed);

lumValues_mixed = (1./ND_mixed') * backL_mixed/15 * maxL;

lum_edge_mixed = (1./ND_mixed') * edgeL_mixed/15 * maxL;

Adaptlum_mixed = (mean(lumValues_mixed, 2)*(0.5 + 0.75/2) + mean(lum_edge_mixed, 2)*0.75/2)/(0.5 + 0.75 + 1);

pred_response_mixed_1 = zeros(size(lumValues_mixed));
pred_response_mixed_2 = zeros(size(lumValues_mixed));
pred_response_1b_lum_mixed = cell(length(ND_mixed), 1);
pred_response_2b_lum_mixed = cell(length(ND_mixed), 1);
pred_response_1_lum_mixed = cell(length(ND_mixed), 1);
pred_response_2_lum_mixed = cell(length(ND_mixed), 1);
pred_response_1b_mixed = cell(length(ND_mixed), 1);
pred_response_2b_mixed = cell(length(ND_mixed), 1);
correction_L2_lum_mixed = cell(length(ND_mixed), 1);
correction_L3_lum_mixed = cell(length(ND_mixed), 1);
correction_L2_mixed = cell(length(ND_mixed), 1);
correction_L3_mixed = cell(length(ND_mixed), 1);
log10_lum_mixed = cell(length(ND_mixed), 1);

%mixed contrasts%
for i = 1:ND_num
        [pred_response_1b_mixed{i}, pred_response_2b_mixed{i}] = predict_response(lum_edge_mixed(i, 1), Adaptlum_mixed(i), ...
                Adaptlum_mixed(i), f, k0_avg, kI, Im, coeff_avg);
        
        log10_lum_mixed{i} = linspace(min(log10(lumValues_mixed(i, :))), max(log10(lumValues_mixed(i, :))), 100);
        
        lum_edge_i = lum_edge_mixed(i, 1) * ones(1, length(log10_lum_mixed{i}));
        
        [pred_response_1b_lum_mixed{i}, pred_response_2b_lum_mixed{i}] = predict_response(lum_edge_i, ...
                10.^log10_lum_mixed{i}, 10.^log10_lum_mixed{i}, f, k0_avg, kI, Im, coeff_avg);
        
        [pred_response_1_lum_mixed{i}, pred_response_2_lum_mixed{i}, correction_L2_lum_mixed{i}, correction_L3_lum_mixed{i}] = ...
                predict_response(lum_edge_i, 10.^log10_lum_mixed{i}, Adaptlum_mixed(i), f, k0_avg, kI, Im, coeff_avg);
        [pred_response_mixed_1(i, :), pred_response_mixed_2(i, :), correction_L2_mixed{i}, correction_L3_mixed{i}] = ...
                predict_response(lum_edge_mixed(i, :), lumValues_mixed(i, :), Adaptlum_mixed(i), f, k0_avg, kI, Im, coeff_avg);
end

pred_response_1b_lum_mixed_all = cell2mat(pred_response_1b_lum_mixed);
pred_response_2b_lum_mixed_all = cell2mat(pred_response_2b_lum_mixed);
log10_lum_mixed_all = cell2mat(log10_lum_mixed);

function [pred_control, pred_no_L3, correction_L2, correction_L3] = predict_response(lum_edge, luminance, adapt_lum, f, k0, kI, Im, coeffs)
  
        app_contrast = (lum_edge - luminance)./adapt_lum;
        contrast = (lum_edge - luminance)./luminance;
        
        k1 = k0*f(log10(adapt_lum))/f.a;
        L2_response = - tanh(app_contrast .* k1');
        
        lum_edge = max(1, (1+contrast) .* luminance);
        
        filter_high = 1./(1+exp(- kI*(log10(luminance) - log10(Im))));
        L3_response_high = L2_response .* filter_high;
        L3_response_low = log10(luminance) .* (1 - filter_high);
        
        pred_control = coeffs(1) + coeffs(2) * L2_response + coeffs(3) + coeffs(4) * filter_high +...
                coeffs(5) * L3_response_high + coeffs(6) * L3_response_low + coeffs(7) * log10(lum_edge) .* tanh(lum_edge);
        
        pred_no_L3 = coeffs(1) + coeffs(2) * L2_response;
        
        %coeffs{3,1} + coeffs{4,1} * filter_high +...
          %      coeffs{6,1} * L3_response_low + ...
         %       coeffs{7,1} * log10(lum_edge) .* tanh(lum_edge);
        
         k1_lum = k0*f(log10(luminance))/f.a;
        correction_L2 = coeffs(2)*(-L2_response - tanh(contrast .* k1_lum'));
        
        %correction_L2_2 = (coeffs{2,1} + coeffs{5,1}*filter_high) .* ...
           %     (L2_response - 1./(1+exp(contrast .* k1)) - 0.5);
        
        correction_L3 = pred_control - pred_no_L3 - correction_L2;% - correction_L2_2;

end




        




