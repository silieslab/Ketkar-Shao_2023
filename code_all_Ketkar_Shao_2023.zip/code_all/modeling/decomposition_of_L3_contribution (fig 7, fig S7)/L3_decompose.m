maxL = 1176758.88; %maximal luminance

ND_100 = [1, 8, 64, 512, 4096];
ND_50 = ND_100;
ND_80 = ND_100;

backL_100 = [1, 2, 4, 8, 15];
backL_50 = [2, 4, 6, 8, 10];
backL_80 = [5, 10, 15];

lumValues_100 = (1./ND_100') * backL_100/15 * maxL;
Adaptlum_100 = mean(lumValues_100, 2)*(0.5 + 0.75/2)/(0.5 + 0.75 + 1);

lumValues_50 = (1./ND_50') * backL_50/15 * maxL;
Adaptlum_50 = mean(lumValues_50, 2)*(0.5 + 0.75/2 + 0.75/2*0.5)/(0.5 + 0.75 + 1);

lumValues_80 = (1./ND_80') * backL_80/15 * maxL;
Adaptlum_80 = mean(lumValues_80, 2)*(0.5 + 0.75/2 + 0.75/2*0.2)/(0.5 + 0.75 + 1);

Im = lumValues_100(4, 3);
kI = 10;

data = table2array(readtable('D:\folders\fly_motion_detection\lum_con_integration project\Madhura_codes\contrastResponses.csv'));
f = fit(data(:,1), data(:,2), 'a/(1+exp(-b*(x-c)))', 'StartPoint', [100, 1, 5]);

log10_lum = (1:0.01:6.5);

load('../train_on_uniform/bootstrap_uniform.mat')

k0_all = zeros(length(mdl_info), 1);
coeff_all = zeros(size(mdl_info{1}.coeff, 1), length(mdl_info));
for i = 1:length(mdl_info)
        k0_all(i) = mdl_info{i}.k0;
        coeff_all(:, i) = mdl_info{i}.coeff(:, 1);
end

k0_avg = mean(k0_all);
coeff_avg = mean(coeff_all, 2);

%100%
[pred_response_1b, pred_response_2b] = predict_response(-1, Adaptlum_100', Adaptlum_100', f, k0_avg, kI, Im, coeff_avg);

[pred_response_1b_lum, pred_response_2b_lum] = predict_response(-1, 10.^log10_lum, 10.^log10_lum, f, k0_avg, kI, Im, coeff_avg);

log10_lum_ND_100 = cell(length(ND_100), 1);
pred_response_1 = zeros(size(lumValues_100));
pred_response_2 = zeros(size(lumValues_100));
pred_response_1_ND_lum = cell(length(ND_100), 1);
pred_response_2_ND_lum = cell(length(ND_100), 1);
correction_L2_100_ND_lum = cell(length(ND_100), 1);
correction_L3_100_ND_lum = cell(length(ND_100), 1);
correction_L2_100_ND = cell(length(ND_100), 1);
correction_L3_100_ND = cell(length(ND_100), 1);
correction_L3_100_ND_2 = cell(length(ND_100), 1);
correction_L3_100_ND_lum_2 = cell(length(ND_100), 1);

for i = 1:length(ND_100)
        log10_lum_ND_100{i} = linspace(min(log10(lumValues_100(i, :))), max(log10(lumValues_100(i, :))), 100);
        [pred_response_1_ND_lum{i}, pred_response_2_ND_lum{i}, correction_L2_100_ND_lum{i}, correction_L3_100_ND_lum{i}] = ...
                predict_response(-1, 10.^log10_lum_ND_100{i}, Adaptlum_100(i), f, k0_avg, kI, Im, coeff_avg);
        [pred_response_1(i, :), pred_response_2(i, :), correction_L2_100_ND{i}, correction_L3_100_ND{i}] = ...
                predict_response(-1, lumValues_100(i, :), Adaptlum_100(i), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_100_ND_2{i}] = ...
                predict_response(-1, lumValues_100(i, :), lumValues_100(i, :), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_100_ND_lum_2{i}] = ...
                predict_response(-1, 10.^log10_lum_ND_100{i}, 10.^log10_lum_ND_100{i}, f, k0_avg, kI, Im, coeff_avg);
end

pred_response_1_ND_lum = cell2mat(pred_response_1_ND_lum);
pred_response_2_ND_lum = cell2mat(pred_response_2_ND_lum);
log10_lum_ND_100 = cell2mat(log10_lum_ND_100);

%80%
[pred_response_5b, pred_response_6b] = predict_response(-0.8, Adaptlum_80', Adaptlum_80', f, k0_avg, kI, Im, coeff_avg);

[pred_response_5b_lum, pred_response_6b_lum] = predict_response(-0.8, 10.^log10_lum, 10.^log10_lum, f, k0_avg, kI, Im, coeff_avg);

log10_lum_ND_80 = cell(length(ND_80), 1);
pred_response_5 = zeros(size(lumValues_80));
pred_response_6 = zeros(size(lumValues_80));
pred_response_5_ND_lum = cell(length(ND_80), 1);
pred_response_6_ND_lum = cell(length(ND_80), 1);
correction_L2_80_ND_lum = cell(length(ND_80), 1);
correction_L3_80_ND_lum = cell(length(ND_80), 1);
correction_L2_80_ND = cell(length(ND_80), 1);
correction_L3_80_ND = cell(length(ND_80), 1);
correction_L3_80_ND_2 = cell(length(ND_80), 1);
correction_L3_80_ND_lum_2 = cell(length(ND_80), 1);

for i = 1:length(ND_80)
        log10_lum_ND_80{i} = linspace(min(log10(lumValues_80(i, :))), max(log10(lumValues_80(i, :))), 100);
        [pred_response_5_ND_lum{i}, pred_response_6_ND_lum{i}, correction_L2_80_ND_lum{i}, correction_L3_80_ND_lum{i}] = ...
                predict_response(-0.8, 10.^log10_lum_ND_80{i}, Adaptlum_80(i), f, k0_avg, kI, Im, coeff_avg);
        [pred_response_5(i, :), pred_response_6(i, :), correction_L2_80_ND{i}, correction_L3_80_ND{i}] = ...
                predict_response(-0.8, lumValues_80(i, :), Adaptlum_80(i), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_80_ND_2{i}] = ...
                predict_response(-0.8, lumValues_80(i, :), lumValues_80(i, :), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_80_ND_lum_2{i}] = ...
                predict_response(-0.8, 10.^log10_lum_ND_80{i}, 10.^log10_lum_ND_80{i}, f, k0_avg, kI, Im, coeff_avg);
end

pred_response_5_ND_lum = cell2mat(pred_response_5_ND_lum);
pred_response_6_ND_lum = cell2mat(pred_response_6_ND_lum);
log10_lum_ND_80 = cell2mat(log10_lum_ND_80);

%50%
[pred_response_3b, pred_response_4b] = predict_response(-0.5, Adaptlum_50', Adaptlum_50', f, k0_avg, kI, Im, coeff_avg);

[pred_response_3b_lum, pred_response_4b_lum] = predict_response(-0.5, 10.^log10_lum, 10.^log10_lum, f, k0_avg, kI, Im, coeff_avg);

log10_lum_ND_50 = cell(length(ND_50), 1);
pred_response_3 = zeros(size(lumValues_50));
pred_response_4 = zeros(size(lumValues_50));
pred_response_3_ND_lum = cell(length(ND_50), 1);
pred_response_4_ND_lum = cell(length(ND_50), 1);
correction_L2_50_ND_lum = cell(length(ND_50), 1);
correction_L3_50_ND_lum = cell(length(ND_50), 1);
correction_L2_50_ND = cell(length(ND_50), 1);
correction_L3_50_ND = cell(length(ND_50), 1);
correction_L3_50_ND_2 = cell(length(ND_50), 1);
correction_L3_50_ND_lum_2 = cell(length(ND_50), 1);

for i = 1:length(ND_50)
        log10_lum_ND_50{i} = linspace(min(log10(lumValues_50(i, :))), max(log10(lumValues_50(i, :))), 100);
        [pred_response_3_ND_lum{i}, pred_response_4_ND_lum{i}, correction_L2_50_ND_lum{i}, correction_L3_50_ND_lum{i}] = ...
                predict_response(-0.5, 10.^log10_lum_ND_50{i}, Adaptlum_50(i), f, k0_avg, kI, Im, coeff_avg);
        [pred_response_3(i, :), pred_response_4(i, :), correction_L2_50_ND{i}, correction_L3_50_ND{i}] = ...
                predict_response(-0.5, lumValues_50(i, :), Adaptlum_50(i), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_50_ND_2{i}] = ...
                predict_response(-0.5, lumValues_50(i, :), lumValues_50(i, :), f, k0_avg, kI, Im, coeff_avg);
        [~, ~, ~, correction_L3_50_ND_lum_2{i}] = ...
                predict_response(-0.5, 10.^log10_lum_ND_50{i}, 10.^log10_lum_ND_50{i}, f, k0_avg, kI, Im, coeff_avg);
end

pred_response_3_ND_lum = cell2mat(pred_response_3_ND_lum);
pred_response_4_ND_lum = cell2mat(pred_response_4_ND_lum);
log10_lum_ND_50 = cell2mat(log10_lum_ND_50);


function [pred_control, pred_no_L3, correction_L2, correction_L3] = predict_response(contrast, luminance, adapt_lum, f, k0, kI, Im, coeffs)
  
        app_contrast = contrast*luminance./adapt_lum;
        
        k1 = k0*f(log10(adapt_lum))/f.a;
        L2_response = - tanh(app_contrast .* k1');
        
        lum_edge = max(1, (1+contrast) .* luminance);
        
        filter_high = 1./(1+exp(- kI*(log10(luminance) - log10(Im))));
        L3_response_high = L2_response .* filter_high;
        L3_response_low = log10(luminance) .* (1 - filter_high);
        
        pred_control = coeffs(1) + coeffs(2) * L2_response + coeffs(3) + coeffs(4) * filter_high +...
                coeffs(5) * L3_response_high + coeffs(6) * L3_response_low + coeffs(7) * log10(lum_edge) .* tanh(lum_edge);
        
        pred_no_L3 = coeffs(1) + coeffs(2) * L2_response;
        
        %coeffs{3,1} + coeffs{4,1} * filter_high +...
          %      coeffs{6,1} * L3_response_low + ...
         %       coeffs{7,1} * log10(lum_edge) .* tanh(lum_edge);
        
         k1_lum = k0*f(log10(luminance))/f.a;
        correction_L2 = coeffs(2)*(-L2_response - tanh(contrast .* k1_lum'));
        
        %correction_L2_2 = (coeffs{2,1} + coeffs{5,1}*filter_high) .* ...
           %     (L2_response - 1./(1+exp(contrast .* k1)) - 0.5);
        
        correction_L3 = pred_control - pred_no_L3 - correction_L2;% - correction_L2_2;

end




        




