%train on mixed contrast dataset

%Laughlin fig 4
data = readmatrix('D:\folders\fly_motion_detection\lum_con_integration project\Madhura_codes\contrastResponses.csv');
f=fit(data(:,1), data(:,2), 'a/(1+exp(-b*(x-c)))', 'StartPoint', [100, 1, 5]);

%k0 = 1.17; %slope when intensity is 5.5e5
%k0 = 0.4*f.a/f(log10(5.5)+3);

maxL = 1176758.88; %maximal luminance

ND_mixed = [1, 8, 64, 512, 4096];
backL_mixed = [2, 3, 4, 5, 6, 8];
edgeL_mixed = [1, 1, 1, 1, 1, 1];

ND_num = length(ND_mixed);
levels = length(backL_mixed);

lumValues_mixed = (1./ND_mixed') * backL_mixed/15 * maxL;

Im =  612.895;
kI = 10;

file_mixed_1 = dir('../mixed_contrasts_Off_int_turn/UAS*.mat');

int_turn_mixed_1 = zeros(length(file_mixed_1), levels);
int_turn_mixed_1_sem = zeros(length(file_mixed_1), levels);
contrast_mixed = zeros(length(file_mixed_1), levels);
L2_response_mixed = zeros(length(file_mixed_1), levels);
luminance_mixed = lumValues_mixed;
lum_edge_mixed = (1./ND_mixed') * edgeL_mixed/15 * maxL;

Adaptlum_mixed = (mean(lumValues_mixed, 2)*(0.5 + 0.75/2) + mean(lum_edge_mixed, 2)*0.75/2)/(0.5 + 0.75 + 1);

for index = 1:length(file_mixed_1)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_1(index).name]);
        int_turn_mixed_1(index, :) = groupMean;
        int_turn_mixed_1_sem(index, :) = groupSEM;
        contrast_mixed(index, :) = (lum_edge_mixed(index, :) - lumValues_mixed(index, :))/Adaptlum_mixed(index);
        k1 = k0*f(log10(Adaptlum_mixed(index)))/f.a;
        L2_response_mixed(index, :) = - tanh(contrast_mixed(index, :)*k1); 
end

file_mixed_2 = dir('../mixed_contrasts_Off_int_turn/L3*.mat');

int_turn_mixed_2 = zeros(length(file_mixed_2), levels);
int_turn_mixed_2_sem = zeros(length(file_mixed_2), levels);

for index = 1:length(file_mixed_2)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_2(index).name]);
        int_turn_mixed_2(index, :) = groupMean;
        int_turn_mixed_2_sem(index, :) = groupSEM;
end

filter_high_mixed = 1./(1+exp(- kI*(log10(luminance_mixed) - log10(Im))));
L3_response_high_mixed = L2_response_mixed .* filter_high_mixed;
L3_response_low_mixed = log10(luminance_mixed) .* (1 - filter_high_mixed);

L2_response_all = [L2_response_mixed(:); L2_response_mixed(:)];

L3_active_all = [ones(length(file_mixed_1)*levels, 1); zeros(length(file_mixed_2)*levels, 1)];

lum_edge_all = [lum_edge_mixed(:); lum_edge_mixed(:)];

filter_high_all = [filter_high_mixed(:); filter_high_mixed(:)];

L3_response_high_all = [L3_response_high_mixed(:); L3_response_high_mixed(:)];

L3_response_low_all = [L3_response_low_mixed(:); L3_response_low_mixed(:)];

real_response_all = [int_turn_mixed_1(:); int_turn_mixed_2(:)];

L3_blocked_response_all = [int_turn_mixed_2(:); int_turn_mixed_2(:)];

fitx_1 = L2_response_all;

idx_train = setdiff(1:length(real_response_all), idx_test);

idx_train_1 = intersect(idx_train, find(L3_active_all == 0));
mdl1 = fitlm(fitx_1(idx_train_1, :), real_response_all(idx_train_1));

fitx_2 = L3_active_all .* [filter_high_all, L3_response_high_all, ...
        L3_response_low_all, log10(lum_edge_all) .* tanh(lum_edge_all)];

idx_train_2 = intersect(idx_train, find(L3_active_all == 1));
mdl2 = fitlm(fitx_2(idx_train_2, :), real_response_all(idx_train_2) - L3_blocked_response_all(idx_train_2));

pred_response_mixed_1 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_mixed + ...
        mdl2.Coefficients{1,1} + mdl2.Coefficients{2,1} * filter_high_mixed +...
        mdl2.Coefficients{3,1} * L3_response_high_mixed + mdl2.Coefficients{4,1} * L3_response_low_mixed + ...
        mdl2.Coefficients{5,1} * log10(lum_edge_mixed) .* tanh(lum_edge_mixed);

pred_response_mixed_2 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_mixed;

R_sq1 = mdl1.Rsquared.Ordinary;
R_sq2 = mdl2.Rsquared.Ordinary;

pred_response_mixed_reshape_1 = pred_response_mixed_1(:);
pred_response_mixed_reshape_2 = pred_response_mixed_2(:);
real_response_mixed_reshape_1 = int_turn_mixed_1(:);
real_response_mixed_reshape_2 = int_turn_mixed_2(:);
pred_response_mixed_reshape = [pred_response_mixed_reshape_1; pred_response_mixed_reshape_2];
real_response_mixed_reshape = [real_response_mixed_reshape_1; real_response_mixed_reshape_2];

SS_tot_mixed_1 = sum((real_response_mixed_reshape_1 - mean(real_response_mixed_reshape_1)).^2);
SS_res_mixed_1 = sum((real_response_mixed_reshape_1 - pred_response_mixed_reshape_1).^2);
R_sq_mixed_1 = 1 - SS_res_mixed_1/SS_tot_mixed_1;

SS_tot_mixed_2 = sum((real_response_mixed_reshape_2 - mean(real_response_mixed_reshape_2)).^2);
SS_res_mixed_2 = sum((real_response_mixed_reshape_2 - pred_response_mixed_reshape_2).^2);
R_sq_mixed_2 = 1 - SS_res_mixed_2/SS_tot_mixed_2;

SS_tot_mixed = sum((real_response_mixed_reshape - mean(real_response_mixed_reshape)).^2);
SS_res_mixed = sum((real_response_mixed_reshape - pred_response_mixed_reshape).^2);
R_sq_mixed = 1-SS_res_mixed/SS_tot_mixed;

SS_tot_test = sum((real_response_mixed_reshape(idx_test) - mean(real_response_mixed_reshape(idx_test))).^2);
SS_res_test = sum((real_response_mixed_reshape(idx_test) - pred_response_mixed_reshape(idx_test)).^2);
R_sq_test = 1 - SS_res_test/SS_tot_test;

SS_tot_train = sum((real_response_mixed_reshape(idx_train) - mean(real_response_mixed_reshape(idx_train))).^2);
SS_res_train = sum((real_response_mixed_reshape(idx_train) - pred_response_mixed_reshape(idx_train)).^2);
R_sq_train = 1 - SS_res_train/SS_tot_train;




