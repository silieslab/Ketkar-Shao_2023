figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

output_dir = 'figures_bootstrap_mixed/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

line_colors_100 = [44, 166, 224; 0, 159, 232; 3, 110, 183; 0, 81, 133; 22, 29, 90]/255;
line_colors_80 = [209, 12, 24; 188, 16, 25; 163, 14, 22; 137, 6, 13; 107, 0, 4]/255;
control_colors = [0.75, 0.75, 0.75; 0.65, 0.65, 0.65; 0.5, 0.5, 0.5; 0.4, 0.4, 0.4; 0, 0, 0];
L2_colors = [71, 175, 55; 44, 171, 58; 17, 153, 60; 16, 128, 57; 13, 103, 50]/255;
mixed_control_colors = [27, 26, 25; 31, 31, 31; 61, 61, 61; 92, 92, 92; 122, 122, 122; 153, 153, 153]/255;
mixed_L2_colors = [13, 103, 50; 24, 118, 51; 35, 133, 52; 46, 148, 53; 57, 163, 54; 68, 178, 58]/255;
mixed_mkr = {'o', 'v', 'p', 's', '^', 'd'};

%mixed model
ax = axes('Position', [0.07, 0.38, 0.4, 0.128]);
hold on;
for i = 1:5
        errorbar(log10(lumValues_mixed(i, :))', avg_pred_mixed_1(i, :)', std_pred_mixed_1(i, :)', ...
                'linewidth', 0.75, 'color', control_colors(i, :), 'CapSize', 2.2)
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), avg_pred_mixed_1(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_control_colors(j, :))
        end
        errorbar(log10(lumValues_mixed(i, :))', avg_pred_mixed_2(i, :)', std_pred_mixed_2(i, :)', ...
                'linewidth', 0.75, 'color', L2_colors(i, :), 'CapSize', 2.2)
        for j = 1:6
                scatter(log10(lumValues_mixed(i, j)), avg_pred_mixed_2(i, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_L2_colors(j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])

%all data, mixed contrasts
ax = axes('Position', [0.57, 0.38, 0.213, 0.128]);
hold on;
for j = 1:6
         scatter(int_turn_mixed_1(:, j), avg_pred_mixed_1(:, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_control_colors(j, :))
         scatter(int_turn_mixed_2(:, j), avg_pred_mixed_2(:, j), 6.96+5*(j == 3), 'filled', ...
                        mixed_mkr{j}, 'MarkerFaceColor', mixed_L2_colors(j, :))
end
plot([-0.2,1],[-0.2,1],'k', 'LineStyle', '--')
xlabel('Observed responses (rad)')
ylabel('Predicted responses (rad)')
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
text(0.6, 0.1, ['R^2 = ', num2str(round(R_sq_test_all_iter, 3))], 'Fontsize', 8*0.7);
xticks(-0.2:0.2:1)
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([-0.2 1.0])
ylim([-0.2 1.0])

annotation('textbox', [0.51, 0.6, 0.4, 0], 'string', ['Averge R^2 over all iterations: ', ...
        num2str(round(mean(R_sq_rand_test), 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')
annotation('textbox', [0.51, 0.58, 0.4, 0], 'string', ['R^2 for predictions on mixed contrast dataset: ', ...
        num2str(round(R_sq_test_all_iter, 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')

set(gcf, 'Renderer', 'painters');
savefig([output_dir, 'bootstrap_mixed.fig'])
saveas(gcf, [output_dir, 'bootstrap_mixed.pdf'])

set(groot,'defaultAxesColorOrder', 'remove')

