%put all panels together

fig_size = [800, 336];
output_dir = 'figures_bootstrap_mixed/';

if ~isfolder(output_dir)
        mkdir(output_dir)
end

figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

line_colors_100 = [44, 166, 224; 0, 159, 232; 3, 110, 183; 0, 81, 133; 22, 29, 90]/255;
line_colors_80 = [209, 12, 24; 188, 16, 25; 163, 14, 22; 137, 6, 13; 107, 0, 4]/255;
control_colors = [0.75, 0.75, 0.75; 0.65, 0.65, 0.65; 0.5, 0.5, 0.5; 0.4, 0.4, 0.4; 0, 0, 0];
L2_colors = [71, 175, 55; 44, 171, 58; 17, 153, 60; 16, 128, 57; 13, 103, 50]/255;
mixed_control_colors = [27, 26, 25; 31, 31, 31; 61, 61, 61; 92, 92, 92; 122, 122, 122; 153, 153, 153]/255;
mixed_L2_colors = [13, 103, 50; 24, 118, 51; 35, 133, 52; 46, 148, 53; 57, 163, 54; 68, 178, 58]/255;
mixed_mkr = {'o', 'v', 'p', 's', '^', 'd'};

%std

figure('Units', 'centimeters', 'Position', [1, 1, 21*0.7, 29.7*0.7])
set(gcf, 'color', [1, 1, 1])

%80% prediction
ax = axes('Position', [0.07, 0.8, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_80(i, :))', avg_pred_5(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:3
                errorbar(log10(lumValues_80(i, j)), avg_pred_5(i, j), std_pred_5(i, j), 'linewidth', 0.75, ...
                        'color', control_colors(6-j, :), 'CapSize', 2.2)
                scatter(log10(lumValues_80(i, j)), avg_pred_5(i, j), 6.96, 'filled', mixed_mkr{4}, ...
                        'MarkerFaceColor', control_colors(7-2*j, :))
        end
        plot(log10(lumValues_80(i, :))', avg_pred_6(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:3
                errorbar(log10(lumValues_80(i, j)), avg_pred_6(i, j), std_pred_6(i, j), 'linewidth', 0.75, ...
                        'color', L2_colors(6-j, :), 'CapSize', 2.2)
                scatter(log10(lumValues_80(i, j)), avg_pred_6(i, j), 6.96, 'filled', mixed_mkr{4}, ...
                        'MarkerFaceColor', L2_colors(7-2*j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])

annotation('textbox', [0.01, 0.97, 0, 0], 'string', '\bfA', 'FontSize', 18*0.7, 'FontName', 'Arial')

%50% prediction
ax = axes('Position', [0.07, 0.6, 0.4, 0.128]);
hold on;
for i = 1:5
        plot(log10(lumValues_50(i, :))', avg_pred_3(i, :)', 'linewidth', 0.75, 'color', control_colors(i, :))
        for j = 1:5
                errorbar(log10(lumValues_50(i, j)), avg_pred_3(i, j), std_pred_3(i, j), 'linewidth', 0.75, ...
                        'color', control_colors(6-j, :), 'CapSize', 2.2)
                scatter(log10(lumValues_50(i, j)), avg_pred_3(i, j), 6.96, 'filled', 'MarkerFaceColor', control_colors(6-j, :))
        end
        plot(log10(lumValues_50(i, :))', avg_pred_4(i, :)', 'linewidth', 0.75, 'color', L2_colors(i, :))
        for j = 1:5
                errorbar(log10(lumValues_50(i, j)), avg_pred_4(i, j), std_pred_4(i, j), 'linewidth', 0.75, ...
                        'color', L2_colors(6-j, :), 'CapSize', 2.2)
                scatter(log10(lumValues_50(i, j)), avg_pred_4(i, j), 6.96, 'filled', 'MarkerFaceColor', L2_colors(6-j, :))
        end
end
xlabel('Background luminance (photons s^{-1} receptor^{-1})')
ylabel('Predicted responses (rad)')
xticks(1:6)
xticklabels({'10^1', '10^2', '10^3', '10^4', '10^5', '10^6'})
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
xlim([1.0 6.5])
ylim([-0.2 1.0])

annotation('textbox', [0.01, 0.77, 0, 0], 'string', '\bfB', 'FontSize', 18*0.7, 'FontName', 'Arial')

%all data points (80% and 50%)

avg_pred_50_80 = [avg_pred_3(:); avg_pred_4(:); avg_pred_5(:); avg_pred_6(:)];
real_response_50_80 = [int_turn_3(:); int_turn_4(:); int_turn_5(:); int_turn_6(:)];
SS_tot_test_50_80 = sum((real_response_50_80 - mean(real_response_50_80)).^2);
SS_res_test_50_80 = sum((real_response_50_80 - avg_pred_50_80).^2);
R_sq_test_50_80 = 1 - SS_res_test_50_80/SS_tot_test_50_80;

ax = axes('Position', [0.57, 0.8, 0.213, 0.128]);
hold on;
%scatter(int_turn_1(:), avg_pred_1(:), 6.96, 'MarkerEdgeColor', mixed_control_colors(6, :))
scatter(int_turn_3(:), avg_pred_3(:), 6.96, 'filled', mixed_mkr{1}, 'MarkerFaceColor', mixed_control_colors(1, :))
scatter(int_turn_5(:), avg_pred_5(:), 6.96, 'filled', mixed_mkr{4}, 'MarkerFaceColor', mixed_control_colors(4, :))
%scatter(int_turn_2(:), avg_pred_2(:), 6.96, 'MarkerEdgeColor', mixed_L2_colors(6, :))
scatter(int_turn_4(:), avg_pred_4(:), 6.96, 'filled', mixed_mkr{1}, 'MarkerFaceColor', mixed_L2_colors(1, :))
scatter(int_turn_6(:), avg_pred_6(:), 6.96, 'filled', mixed_mkr{4}, 'MarkerFaceColor', mixed_L2_colors(4, :))
plot([-0.2,1.0], [-0.2,1.0], 'k', 'LineStyle', '--')
xticks(-0.2:0.2:1)
yticks(-0.2:0.2:1)
a = get(ax,'Label');
set(gca,'Label', a,'fontsize', 8*0.7);
set(gca, 'Box', 'off')
set(ax, 'TickDir', 'out')
set(ax, 'LineWidth', 0.5)
set(ax, 'FontName', 'Arial')
text(0.6, 0.1, ['R^2 = ', num2str(round(R_sq_test_50_80, 3))], 'FontSize', 8*0.7)
xlim([-0.2 1.0])
ylim([-0.2 1.0])
xlabel('Observed responses (rad)')
ylabel('Predicted responses (rad)')

annotation('textbox', [0.51, 0.97, 0, 0], 'string', '\bfC', 'FontSize', 18*0.7, 'FontName', 'Arial')

%R^2
annotation('textbox', [0.51, 0.7, 0.4, 0], 'string', ['Averge R^2 over all iterations: ', ...
        num2str(round(mean(R_sq_all), 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')
annotation('textbox', [0.51, 0.68, 0.4, 0], 'string', ['R^2 for predictions on all contrasts: ', ...
        num2str(round(R_sq_test_uniform_avg, 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')
%annotation('textbox', [0.51, 0.66, 0.4, 0], 'string', ['R^2 for predictions on -100%: ', ...
    %    num2str(round(R_sq_test_100_avg, 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')
annotation('textbox', [0.51, 0.66, 0.4, 0], 'string', ['R^2 for predictions on -80%: ', ...
        num2str(round(R_sq_test_80_avg, 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')
annotation('textbox', [0.51, 0.64, 0.4, 0], 'string', ['R^2 for predictions on -50%: ', ...
        num2str(round(R_sq_test_50_avg, 3))], 'FontSize', 10*0.7, 'FontName', 'Arial', 'LineStyle', 'none')

set(gcf, 'Renderer', 'painters');
savefig([output_dir, 'pred_50_80.fig'])
saveas(gcf, [output_dir, 'pred_50_80.pdf'])

set(groot,'defaultAxesColorOrder', 'remove')



