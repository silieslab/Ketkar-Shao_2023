%100%: 0-50
%50%: 51-100
%80%: 101-130

idx_info_dir = '../../jupyter_notebook/Model 45/';

load([idx_info_dir, 'bootstrap_uniform_info.mat'])

idx_test_rand = idx_test_rand + 1;

R_sq_rand_test = zeros(size(k0_rand));
R_sq_rand_train = zeros(size(k0_rand));
R_sq_rand_train_1 = zeros(size(k0_rand));
R_sq_rand_train_2 = zeros(size(k0_rand));

mdl_info = cell(size(k0_rand));

pred_all_iter = cell(130, 1);

for i = 1:length(k0_rand)
        k0 = k0_rand(i);
        idx_test = squeeze(idx_test_rand(i, :));
        bootstrap_fun;
        mdl_info{i}.coeff = [table2array(mdl1.Coefficients); table2array(mdl2.Coefficients)];
        mdl_info{i}.k0 = k0;
        mdl_info{i}.R_sq1 = mdl1.Rsquared.Ordinary;
        mdl_info{i}.R_sq2 = mdl2.Rsquared.Ordinary;
        mdl_info{i}.R_sq = R_sq_train;
        R_sq_rand_test(i) = R_sq_test;
        R_sq_rand_train(i) = R_sq_train;
        R_sq_rand_train_1(i) = R_sq1;
        R_sq_rand_train_2(i) = R_sq2;
        for j = 1:length(idx_test)
               pred_all_iter{idx_test(j)} = [pred_all_iter{idx_test(j)}, pred_response_all(idx_test(j))];
        end
end

avg_pred_all_iter = zeros(length(pred_all_iter), 1);
sem_pred_all_iter = zeros(length(pred_all_iter), 1);
std_pred_all_iter = zeros(length(pred_all_iter), 1);
for j = 1:length(pred_all_iter)
        avg_pred_all_iter(j) = mean(pred_all_iter{j});
        sem_pred_all_iter(j) = std(pred_all_iter{j})/sqrt(length(pred_all_iter{j}));
        std_pred_all_iter(j) = std(pred_all_iter{j});
end

SS_tot_test_all_iter = sum((real_response_all - mean(real_response_all)).^2);
SS_res_test_all_iter = sum((real_response_all - avg_pred_all_iter).^2);
R_sq_test_all_iter = 1 - SS_res_test_all_iter/SS_tot_test_all_iter;

avg_pred_response_1 = reshape(avg_pred_all_iter(1:25), 5, 5);
avg_pred_response_2 = reshape(avg_pred_all_iter(26:50), 5, 5);
avg_pred_response_3 = reshape(avg_pred_all_iter(51:75), 5, 5);
avg_pred_response_4 = reshape(avg_pred_all_iter(76:100), 5, 5);
avg_pred_response_5 = reshape(avg_pred_all_iter(101:115), 5, 3);
avg_pred_response_6 = reshape(avg_pred_all_iter(116:130), 5, 3);

sem_pred_response_1 = reshape(sem_pred_all_iter(1:25), 5, 5);
sem_pred_response_2 = reshape(sem_pred_all_iter(26:50), 5, 5);
sem_pred_response_3 = reshape(sem_pred_all_iter(51:75), 5, 5);
sem_pred_response_4 = reshape(sem_pred_all_iter(76:100), 5, 5);
sem_pred_response_5 = reshape(sem_pred_all_iter(101:115), 5, 3);
sem_pred_response_6 = reshape(sem_pred_all_iter(116:130), 5, 3);

std_pred_response_1 = reshape(std_pred_all_iter(1:25), 5, 5);
std_pred_response_2 = reshape(std_pred_all_iter(26:50), 5, 5);
std_pred_response_3 = reshape(std_pred_all_iter(51:75), 5, 5);
std_pred_response_4 = reshape(std_pred_all_iter(76:100), 5, 5);
std_pred_response_5 = reshape(std_pred_all_iter(101:115), 5, 3);
std_pred_response_6 = reshape(std_pred_all_iter(116:130), 5, 3);

R_sq_avg_all = mean(R_sq_rand_test);

SS_tot_test_100 = sum((real_response_all(1:50) - mean(real_response_all(1:50))).^2);
SS_res_test_100 = sum((real_response_all(1:50) - avg_pred_all_iter(1:50)).^2);
R_sq_test_100 = 1 - SS_res_test_100/SS_tot_test_100;

SS_tot_test_50 = sum((real_response_all(51:100) - mean(real_response_all(51:100))).^2);
SS_res_test_50 = sum((real_response_all(51:100) - avg_pred_all_iter(51:100)).^2);
R_sq_test_50 = 1 - SS_res_test_50/SS_tot_test_50;

SS_tot_test_80 = sum((real_response_all(101:130) - mean(real_response_all(101:130))).^2);
SS_res_test_80 = sum((real_response_all(101:130) - avg_pred_all_iter(101:130)).^2);
R_sq_test_80 = 1 - SS_res_test_80/SS_tot_test_80;

save('bootstrap_uniform.mat', 'mdl_info')

