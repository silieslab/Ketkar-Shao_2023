%Laughlin fig 4
data = readmatrix('D:\folders\fly_motion_detection\lum_con_integration project\Madhura_codes\contrastResponses.csv');
f = fit(data(:,1), data(:,2), 'a/(1+exp(-b*(x-c)))', 'StartPoint', [100, 1, 5]);

%k0 = 1.08;

maxL = 1176758.88; %maximal luminance

ND_100 = [1, 8, 64, 512, 4096];
ND_50 = ND_100;
ND_80 = ND_100;

backL_100 = [1, 2, 4, 8, 15];
backL_50 = [2, 4, 6, 8, 10];
backL_80 = [5, 10, 15];

lumValues_100 = (1./ND_100') * backL_100/15 * maxL;
Adaptlum_100 = mean(lumValues_100, 2)*(0.5 + 0.75/2)/(0.5 + 0.75 + 1);

Im = lumValues_100(4, 3);
kI = 10;

dir1 = '../uniform_contrasts_Off_int_turn/100%Off/control_2/';
file_1 = dir([dir1, '*.mat']);

levels_100 = size(lumValues_100, 2);
int_turn_1 = zeros(length(file_1), levels_100);
int_turn_1_sem = zeros(length(file_1), levels_100);
contrast_1 = zeros(length(file_1), levels_100);
L2_response_1 = zeros(length(file_1), levels_100);
luminance_1 = lumValues_100;
lum_edge_1 = ones(size(lumValues_100));

for index = 1:length(file_1)
        load([dir1, file_1(index).name]);
        int_turn_1(index, :) = groupMean;
        int_turn_1_sem(index, :) = groupSEM;
        contrast_1(index, :) = - lumValues_100(index, :)/Adaptlum_100(index);
        k1 = k0*f(log10(Adaptlum_100(index)))/f.a;
        L2_response_1(index, :) = - tanh(contrast_1(index, :)*k1);
end

filter_high_100 = 1./(1+exp(- kI*(log10(luminance_1) - log10(Im))));
L3_response_high_100 = L2_response_1 .* filter_high_100;
L3_response_low_100 = log10(luminance_1) .* (1 - filter_high_100);

dir2 = '../uniform_contrasts_Off_int_turn/100%Off/L3_silenced/';
file_2 = dir([dir2, '*.mat']);

int_turn_2 = zeros(length(file_2), levels_100);
int_turn_2_sem = zeros(length(file_2), levels_100);
contrast_2 = zeros(length(file_2), levels_100);
L2_response_2 = zeros(length(file_2), levels_100);
luminance_2 = lumValues_100;
lum_edge_2 = ones(size(lumValues_100));

for index = 1:length(file_2)
        load([dir2, file_2(index).name]);
        int_turn_2(index, :) = groupMean;
        int_turn_2_sem(index, :) = groupSEM;
        contrast_2(index, :) = - lumValues_100(index, :)/Adaptlum_100(index);
        k1 = k0*f(log10(Adaptlum_100(index)))/f.a;
        L2_response_2(index, :) = - tanh(contrast_2(index, :)*k1);
end

%50% contrast
lumValues_50 = (1./ND_50') * backL_50/15 * maxL;
Adaptlum_50 = mean(lumValues_50, 2)*(0.5 + 0.75/2 + 0.75/2*0.5)/(0.5 + 0.75 + 1);

dir3 = '../uniform_contrasts_Off_int_turn/50%Off/control_2/';
file_3 = dir([dir3, '*.mat']);

levels_50 = size(lumValues_50, 2);
int_turn_3 = zeros(length(file_3), levels_50);
int_turn_3_sem = zeros(length(file_3), levels_50);
contrast_3 = zeros(length(file_3), levels_50);
L2_response_3 = zeros(length(file_3), levels_50);
luminance_3 = lumValues_50;
lum_edge_3 = 0.5*lumValues_50;

for index = 1:length(file_3)
        load([dir3, file_3(index).name]);
        int_turn_3(index, :) = groupMean;
        int_turn_3_sem(index, :) = groupSEM;
        contrast_3(index, :) = - 0.5*lumValues_50(index, :)/Adaptlum_50(index);
        k1 = k0*f(log10(Adaptlum_50(index)))/f.a;
        L2_response_3(index, :) = - tanh(contrast_3(index, :)*k1);
end

filter_high_50 = 1./(1+exp(- kI*(log10(luminance_3) - log10(Im))));
L3_response_high_50 = L2_response_3 .* filter_high_50;
L3_response_low_50 = log10(luminance_3) .* (1 - filter_high_50);

dir4 = '../uniform_contrasts_Off_int_turn/50%Off/L3_silenced/';
file_4 = dir([dir4, '*.mat']);

int_turn_4 = zeros(length(file_4), levels_50);
int_turn_4_sem = zeros(length(file_4), levels_50);
contrast_4 = zeros(length(file_4), levels_50);
L2_response_4 = zeros(length(file_4), levels_50);
luminance_4 = lumValues_50;
lum_edge_4 = 0.5*lumValues_50;

for index = 1:length(file_4)
        load([dir4, file_4(index).name]);
        int_turn_4(index, :) = groupMean;
        int_turn_4_sem(index, :) = groupSEM;
        contrast_4(index, :) = - 0.5*lumValues_50(index, :)/Adaptlum_50(index);
        k1 = k0*f(log10(Adaptlum_50(index)))/f.a;
        L2_response_4(index, :) = - tanh(contrast_4(index, :)*k1);
end

%predict on 80% contrast
lumValues_80 = (1./ND_80') * backL_80/15 * maxL;
Adaptlum_80 = mean(lumValues_80, 2)*(0.5 + 0.75/2 + 0.75/2*0.2)/(0.5 + 0.75 + 1);

dir5 = '../uniform_contrasts_Off_int_turn/80%Off/control_2/';
file_5 = dir([dir5, '*.mat']);

levels_80 = size(lumValues_80, 2);
int_turn_5 = zeros(length(file_5), levels_80);
int_turn_5_sem = zeros(length(file_5), levels_80);
contrast_5 = zeros(length(file_5), levels_80);
L2_response_5 = zeros(length(file_5), levels_80);
luminance_5 = lumValues_80;
lum_edge_5 = 0.2*lumValues_80;

for index = 1:length(file_5)
        load([dir5, file_5(index).name]);
        int_turn_5(index, :) = groupMean;
        int_turn_5_sem(index, :) = groupSEM;
        contrast_5(index, :) = - 0.8*lumValues_80(index, :)/Adaptlum_80(index);
        k1 = k0*f(log10(Adaptlum_80(index)))/f.a;
        L2_response_5(index, :) = - tanh(contrast_5(index, :)*k1);
end

filter_high_80 = 1./(1+exp(- kI*(log10(luminance_5) - log10(Im))));
L3_response_high_80 = L2_response_5 .* filter_high_80;
L3_response_low_80 = log10(luminance_5) .* (1 - filter_high_80);

dir6 = '../uniform_contrasts_Off_int_turn/80%Off/L3_silenced/';
file_6 = dir([dir6, '*.mat']);

int_turn_6 = zeros(length(file_6), levels_80);
int_turn_6_sem = zeros(length(file_6), levels_80);
contrast_6 = zeros(length(file_6), levels_80);
L2_response_6 = zeros(length(file_6), levels_80);
luminance_6 = lumValues_80;
lum_edge_6 = 0.2*lumValues_80;

for index = 1:length(file_6)
        load([dir6, file_6(index).name]);
        int_turn_6(index, :) = groupMean;
        int_turn_6_sem(index, :) = groupSEM;
        contrast_6(index, :) = - 0.8*lumValues_80(index, :)/Adaptlum_80(index);
        k1 = k0*f(log10(Adaptlum_80(index)))/f.a;
        L2_response_6(index, :) = - tanh(contrast_6(index, :)*k1);
end

L2_response_all = [L2_response_1(:); L2_response_2(:); L2_response_3(:); ...
        L2_response_4(:); L2_response_5(:); L2_response_6(:)];

L3_active_all = [ones(length(file_1)*levels_100, 1); zeros(length(file_2)*levels_100, 1); ...
        ones(length(file_3)*levels_50, 1); zeros(length(file_4)*levels_50, 1); ...
        ones(length(file_5)*levels_80, 1); zeros(length(file_6)*levels_80, 1)];

lum_edge_all = [lum_edge_1(:); lum_edge_2(:); lum_edge_3(:); ...
        lum_edge_4(:); lum_edge_5(:); lum_edge_6(:)];

filter_high_all = [filter_high_100(:); filter_high_100(:); ...
        filter_high_50(:); filter_high_50(:); ...
        filter_high_80(:); filter_high_80(:)];

L3_response_high_all = [L3_response_high_100(:); L3_response_high_100(:); ...
        L3_response_high_50(:); L3_response_high_50(:); ...
        L3_response_high_80(:); L3_response_high_80(:)];

L3_response_low_all = [L3_response_low_100(:); L3_response_low_100(:); ...
        L3_response_low_50(:); L3_response_low_50(:); ...
        L3_response_low_80(:); L3_response_low_80(:)];

real_response_all = [int_turn_1(:); int_turn_2(:); int_turn_3(:); ...
        int_turn_4(:); int_turn_5(:); int_turn_6(:)];

L3_blocked_response_all = [int_turn_2(:); int_turn_2(:); int_turn_4(:); ...
        int_turn_4(:); int_turn_6(:); int_turn_6(:)];

fitx_1 = L2_response_all;

idx_train = setdiff(1:length(real_response_all), idx_test);

idx_train_1 = intersect(idx_train, find(L3_active_all == 0));
mdl1 = fitlm(fitx_1(idx_train_1, :), real_response_all(idx_train_1));

fitx_2 = L3_active_all .* [filter_high_all, L3_response_high_all, ...
        L3_response_low_all, log10(lum_edge_all) .* tanh(lum_edge_all)];

idx_train_2 = intersect(idx_train, find(L3_active_all == 1));
mdl2 = fitlm(fitx_2(idx_train_2, :), real_response_all(idx_train_2) - L3_blocked_response_all(idx_train_2));

pred_response_1 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_1 + ...
        mdl2.Coefficients{1,1} + mdl2.Coefficients{2,1} * filter_high_100 +...
        mdl2.Coefficients{3,1} * L3_response_high_100 + mdl2.Coefficients{4,1} * L3_response_low_100 + ...
        mdl2.Coefficients{5,1} * log10(lum_edge_1) .* tanh(lum_edge_1);

pred_response_3 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_3 + ...
        mdl2.Coefficients{1,1} + mdl2.Coefficients{2,1} * filter_high_50 +...
        mdl2.Coefficients{3,1} * L3_response_high_50 + mdl2.Coefficients{4,1} * L3_response_low_50 + ...
        mdl2.Coefficients{5,1} * log10(lum_edge_3) .* tanh(lum_edge_3);

pred_response_5 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_5 + ...
        mdl2.Coefficients{1,1} + mdl2.Coefficients{2,1} * filter_high_80 +...
        mdl2.Coefficients{3,1} * L3_response_high_80 + mdl2.Coefficients{4,1} * L3_response_low_80 + ...
        mdl2.Coefficients{5,1} * log10(lum_edge_5) .* tanh(lum_edge_5);

pred_response_2 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_2;
pred_response_4 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_4;
pred_response_6 = mdl1.Coefficients{1,1} + mdl1.Coefficients{2,1} * L2_response_6;

R_sq1 = mdl1.Rsquared.Ordinary;
R_sq2 = mdl2.Rsquared.Ordinary;

pred_response_100 = [pred_response_1(:); pred_response_2(:)];
real_response_100 = [int_turn_1(:); int_turn_2(:)];         
SS_tot_100 = sum((real_response_100 - mean(real_response_100)).^2);
SS_res_100 = sum((real_response_100 - pred_response_100).^2);
R_sq_100 = 1-SS_res_100/SS_tot_100;

pred_response_50 = [pred_response_3(:); pred_response_4(:)];
real_response_50 = [int_turn_3(:); int_turn_4(:)];
SS_tot_50 = sum((real_response_50 - mean(real_response_50)).^2);
SS_res_50 = sum((real_response_50 - pred_response_50).^2);
R_sq_50 = 1-SS_res_50/SS_tot_50;

pred_response_80 = [pred_response_5(:); pred_response_6(:)];
real_response_80 = [int_turn_5(:); int_turn_6(:)];
SS_tot_80 = sum((real_response_80 - mean(real_response_80)).^2);
SS_res_80 = sum((real_response_80 - pred_response_80).^2);
R_sq_80 = 1-SS_res_80/SS_tot_80;

pred_response_all = [pred_response_1(:); pred_response_2(:); pred_response_3(:); ...
        pred_response_4(:); pred_response_5(:); pred_response_6(:)];
SS_tot_test = sum((real_response_all(idx_test) - mean(real_response_all(idx_test))).^2);
SS_res_test = sum((real_response_all(idx_test) - pred_response_all(idx_test)).^2);
R_sq_test = 1 - SS_res_test/SS_tot_test;

SS_tot_train = sum((real_response_all(idx_train) - mean(real_response_all(idx_train))).^2);
SS_res_train = sum((real_response_all(idx_train) - pred_response_all(idx_train)).^2);
R_sq_train = 1 - SS_res_train/SS_tot_train;


