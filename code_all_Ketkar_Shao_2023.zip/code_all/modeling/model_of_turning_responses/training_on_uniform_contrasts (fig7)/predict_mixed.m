ND_mixed = [1, 8, 64, 512, 4096];
backL_mixed = [2, 3, 4, 5, 6, 8];
edgeL_mixed = [1, 1, 1, 1, 1, 1];

ND_num = length(ND_mixed);
levels = length(backL_mixed);

lumValues_mixed = (1./ND_mixed') * backL_mixed/15 * maxL;

contrast_mixed = zeros(ND_num, levels);
L2_response_mixed = zeros(ND_num, levels);
luminance_mixed = lumValues_mixed;
lum_edge_mixed = (1./ND_mixed') * edgeL_mixed/15 * maxL;

Adaptlum_mixed = (mean(lumValues_mixed, 2)*(0.5 + 0.75/2) + mean(lum_edge_mixed, 2)*0.75/2)/(0.5 + 0.75 + 1);

filter_high_mixed = 1./(1+exp(- kI*(log10(luminance_mixed) - log10(Im))));
L3_response_low_mixed = log10(luminance_mixed) .* (1 - filter_high_mixed);

file_mixed_1 = dir('../mixed_contrasts_Off_int_turn/UAS*.mat');

int_turn_mixed_1 = zeros(length(file_mixed_1), levels);
int_turn_mixed_1_sem = zeros(length(file_mixed_1), levels);

for index = 1:length(file_mixed_1)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_1(index).name]);
        int_turn_mixed_1(index, :) = groupMean;
        int_turn_mixed_1_sem(index, :) = groupSEM;
end

file_mixed_2 = dir('../mixed_contrasts_Off_int_turn/L3*.mat');

int_turn_mixed_2 = zeros(length(file_mixed_2), levels);
int_turn_mixed_2_sem = zeros(length(file_mixed_2), levels);

for index = 1:length(file_mixed_2)
        load(['../mixed_contrasts_Off_int_turn/', file_mixed_2(index).name]);
        int_turn_mixed_2(index, :) = groupMean;
        int_turn_mixed_2_sem(index, :) = groupSEM;
end

real_response_mixed_reshape_1 = int_turn_mixed_1(:);
real_response_mixed_reshape_2 = int_turn_mixed_2(:);
real_response_mixed_reshape = [real_response_mixed_reshape_1; real_response_mixed_reshape_2];

load('bootstrap_uniform.mat')

pred_response_mixed_1 = cell(size(mdl_info));
pred_response_mixed_2 = cell(size(mdl_info));

R_sq_mixed_1 = zeros(size(mdl_info));
R_sq_mixed_2 = zeros(size(mdl_info));
R_sq_mixed = zeros(size(mdl_info));

for i = 1:length(mdl_info)

        k0 = mdl_info{i}.k0;
        for index = 1:ND_num
                contrast_mixed(index, :) = (lum_edge_mixed(index, :) - lumValues_mixed(index, :))/Adaptlum_mixed(index);
                k1 = k0*f(log10(Adaptlum_mixed(index)))/f.a;
                L2_response_mixed(index, :) = - tanh(contrast_mixed(index, :)*k1);
        end
        L3_response_high_mixed = L2_response_mixed .* filter_high_mixed;

        pred_response_mixed_1{i} = mdl_info{i}.coeff(1,1) + mdl_info{i}.coeff(2,1) * L2_response_mixed + ...
                mdl_info{i}.coeff(3,1) + mdl_info{i}.coeff(4,1) * filter_high_mixed +...
                mdl_info{i}.coeff(5,1) * L3_response_high_mixed + mdl_info{i}.coeff(6,1) * L3_response_low_mixed + ...
                mdl_info{i}.coeff(7,1) * log10(lum_edge_mixed) .* tanh(lum_edge_mixed);

        pred_response_mixed_2{i} = mdl_info{i}.coeff(1,1) + mdl_info{i}.coeff(2,1) * L2_response_mixed;

        pred_response_mixed_reshape_1 = pred_response_mixed_1{i}(:);
        pred_response_mixed_reshape_2 = pred_response_mixed_2{i}(:);
        pred_response_mixed_reshape = [pred_response_mixed_reshape_1; pred_response_mixed_reshape_2];

        SS_tot_mixed_1 = sum((real_response_mixed_reshape_1 - mean(real_response_mixed_reshape_1)).^2);
        SS_res_mixed_1 = sum((real_response_mixed_reshape_1 - pred_response_mixed_reshape_1).^2);
        R_sq_mixed_1(i) = 1 - SS_res_mixed_1/SS_tot_mixed_1;

        SS_tot_mixed_2 = sum((real_response_mixed_reshape_2 - mean(real_response_mixed_reshape_2)).^2);
        SS_res_mixed_2 = sum((real_response_mixed_reshape_2 - pred_response_mixed_reshape_2).^2);
        R_sq_mixed_2(i) = 1 - SS_res_mixed_2/SS_tot_mixed_2;

        SS_tot_mixed = sum((real_response_mixed_reshape - mean(real_response_mixed_reshape)).^2);
        SS_res_mixed = sum((real_response_mixed_reshape - pred_response_mixed_reshape).^2);
        R_sq_mixed(i) = 1-SS_res_mixed/SS_tot_mixed;

end

avg_pred_mixed_1 = zeros(size(pred_response_mixed_1{1}));
avg_pred_mixed_2 = zeros(size(pred_response_mixed_2{1}));
std_pred_mixed_1 = zeros(size(pred_response_mixed_1{1}));
std_pred_mixed_2 = zeros(size(pred_response_mixed_2{1}));
for i = 1:size(avg_pred_mixed_1, 1)
        for j = 1:size(avg_pred_mixed_1, 2)
                pred_all_iter = zeros(size(mdl_info));
                for k = 1:length(mdl_info)
                        pred_all_iter(k) = pred_response_mixed_1{k}(i, j);
                end
                avg_pred_mixed_1(i, j) = mean(pred_all_iter);
                std_pred_mixed_1(i, j) = std(pred_all_iter);
        end
end

for i = 1:size(avg_pred_mixed_2, 1)
        for j = 1:size(avg_pred_mixed_2, 2)
                pred_all_iter = zeros(size(mdl_info));
                for k = 1:length(mdl_info)
                        pred_all_iter(k) = pred_response_mixed_2{k}(i, j);
                end
                avg_pred_mixed_2(i, j) = mean(pred_all_iter);
                std_pred_mixed_2(i, j) = std(pred_all_iter);
        end
end

avg_pred_mixed = [avg_pred_mixed_1(:); avg_pred_mixed_2(:)];
SS_tot_test_mixed_avg = sum((real_response_mixed_reshape - mean(real_response_mixed_reshape)).^2);
SS_res_test_mixed_avg = sum((real_response_mixed_reshape - avg_pred_mixed).^2);
R_sq_test_mixed_avg = 1 - SS_res_test_mixed_avg/SS_tot_test_mixed_avg;









