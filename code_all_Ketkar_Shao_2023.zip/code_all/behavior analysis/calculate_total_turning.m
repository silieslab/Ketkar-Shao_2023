
%motionstart in this case is at 0.7 (0.2 + onset of moving edge)
%durMotion is flexible
%length(pdata(1).pdata.acc_dtheta) is the #groups (number of different stimuli)

plotting = 0;

calc_int_turns('../new_data/100%Off/', 'pdata_L3[0595]_Gal4', '../uniform_contrasts_Off_int_turn/100%Off/control_1/', plotting);
calc_int_turns('../new_data/100%Off/', 'pdata_UAS_shi', '../uniform_contrasts_Off_int_turn/100%Off/control_2/', plotting);
calc_int_turns('../new_data/100%Off/', 'pdata_L3[0595]_shi[ts]', '../uniform_contrasts_Off_int_turn/100%Off/L3_silenced/', plotting);

calc_int_turns('../new_data/80%Off/', 'pdata_L3[0595]_Gal4', '../uniform_contrasts_Off_int_turn/80%Off/control_1/', plotting);
calc_int_turns('../new_data/80%Off/', 'pdata_UAS-shi', '../uniform_contrasts_Off_int_turn/80%Off/control_2/', plotting);
calc_int_turns('../new_data/80%Off/', 'pdata_L3[0595]_shi[ts]', '../uniform_contrasts_Off_int_turn/80%Off/L3_silenced/', plotting);

calc_int_turns('../new_data/50%Off/', 'pdata_L3[0595]_Gal4', '../uniform_contrasts_Off_int_turn/50%Off/control_1/', plotting);
calc_int_turns('../new_data/50%Off/', 'pdata_UAS-shi', '../uniform_contrasts_Off_int_turn/50%Off/control_2/', plotting);
calc_int_turns('../new_data/50%Off/', 'pdata_L3[0595]_shi[ts]', '../uniform_contrasts_Off_int_turn/50%Off/L3_silenced/', plotting);

calc_int_turns('../new_data/mixed_contrast/', 'pdata_UAS-shi', '../mixed_contrasts_Off_int_turn/', plotting);
calc_int_turns('../new_data/mixed_contrast/', 'pdata_L3[0595]-shi', '../mixed_contrasts_Off_int_turn/', plotting);

function calc_int_turns(data_path, data_name, output_path, plotting)

motionStart = 0.7;
%durMotion = 1.0;
fps = 120;
startFrame = round(motionStart*fps) + 1;
motionStop1 = 1.5;
motionStop2 = 2;
stopFrame1 = round(motionStop1*fps);
stopFrame2 = round(motionStop2*fps);

file = dir([data_path, data_name, '*.mat']);

if ~isfolder(output_path)
        mkdir(output_path)
end

for filenum = 1:length(file)
        load([data_path, file(filenum).name], 'pdata');
        
        flies = length(pdata);

        levels = size(pdata(1).pdata.acc_dtheta, 2);
        IntTurnperFlyperGroup = cell(flies, levels);
        groupMeanperFly = zeros(flies, levels);
        baselineperFly = zeros(flies, levels);
        stopTime = zeros(flies, levels);
        
        if plotting == 1
                figure('Units', 'centimeters', 'Position', [0, 0, 21.0, 29.7])
                set(gcf, 'color', [1 1 1])
        end
        
        for j=1:flies %number of flies
                for i=1:levels % number of groups
                         turning_speed = pdata(j).pdata.acc_dtheta{i};
                         turning_speed = mean(turning_speed);
                         idx_stop = find(turning_speed(stopFrame1:stopFrame2) < 0, 1);
                         if isempty(idx_stop)
                                 stopFrame = stopFrame2;
                         else
                                 stopFrame = max(0, idx_stop - 2) + stopFrame1;
                         end
                         stopTime(j, i) = stopFrame/fps;
                         groupMeanperFly(j, i) = sum(turning_speed(startFrame: stopFrame))/fps;
                         baselineperFly(j, i) = sum(turning_speed(1: round(0.5*fps)))/fps;
                         if plotting == 1
                                 subplot(flies, levels, i + (j-1)*levels)
                                 plot(turning_speed)
                                 hold on
                                 plot([1, 301], [0, 0], 'k')
                                 scatter(stopFrame, 0, 'r')
                         end
                end
        end
        groupMean = mean(groupMeanperFly); %mean across all flies
        baselineMean = mean(baselineperFly);
        groupSEM = std(groupMeanperFly)/sqrt(flies);
        baselineSEM = std(baselineperFly)/sqrt(flies);
        
        save([output_path, file(filenum).name(7:length(file(filenum).name))], 'groupMean', ...
                'groupSEM', 'groupMeanperFly', 'baselineMean', 'baselineSEM', 'baselineperFly', ...
                'IntTurnperFlyperGroup', 'stopTime');
        
        if plotting == 1
                savefig(gcf, [output_path, file(filenum).name(7:length(file(filenum).name)), '_traces.fig'])
                close all
        end
                
end

end

    
